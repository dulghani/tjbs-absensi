import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAuthStore = create(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      company: null,

      setAuth: (user, token) => set({ user, token }),
      setCompany: (company) => set({ company }),
      logout: () => set({ user: null, token: null, company: null }),

      isLoggedIn: () => !!get().token,
      hasRole: (roles) => {
        const user = get().user
        if (!user) return false
        const r = Array.isArray(roles) ? roles : [roles]
        return r.some(role => user.roles?.includes(role))
      },
      hasPermission: (perm) => {
        const user = get().user
        if (!user) return false
        if (user.roles?.includes('super_admin')) return true
        return user.permissions?.includes(perm) || false
      },
    }),
    { name: 'outsourcehr-auth', partialize: (s) => ({ user: s.user, token: s.token, company: s.company }) }
  )
)
