import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Plus, Edit2, Trash2, ShieldCheck, UserCheck, Building2, Users as UsersIcon } from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { getUsers, createUser, getCompanies, getRolePermissions, updateRolePermissions } from '../../api/realService'
import { ALL_PERMISSIONS, ROLE_DEFINITIONS } from '../../api/mockData'
import { Card, CardHeader, CardTitle, CardBody, Select, Input, Switch, EmptyState } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import Modal, { ConfirmModal } from '../../components/ui/Modal'
import { Table, Thead, Tbody, Tr, Th, Td, TableEmpty, Pagination, PageSizeSelector, SortableTh } from '../../components/ui/Table'
import { useTableControls } from '../../hooks/useTableControls'
import { ROLE_LABELS, ROLE_COLORS, initials } from '../../lib/utils'
import { toast } from '../../components/ui/Toast'

const ROLE_ICONS = { coordinator: ShieldCheck, field_officer: UserCheck, hrd: Building2, staff_dept: UsersIcon }

export default function UsersPage() {
  const user = useAuthStore((s) => s.user)
  const role = user?.roles?.[0]
  const canManageAll = role === 'coordinator'

  const [tab, setTab] = useState(0)
  const [users, setUsers] = useState(null)
  const [companies, setCompanies] = useState([])
  const [modalOpen, setModalOpen] = useState(false)
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm()

  const assignableRoles = role === 'coordinator' ? Object.keys(ROLE_DEFINITIONS)
    : role === 'field_officer' ? ['hrd', 'staff_dept']
    : role === 'hrd' ? ['staff_dept'] : []

  useEffect(() => { getCompanies().then(setCompanies); load() }, [])
  async function load() {
    const data = await getUsers({ company_id: canManageAll ? 'all' : user.company_id })
    setUsers(data)
  }

  const tc = useTableControls(users, { defaultSortBy: 'name' })

  async function onSubmit(data) {
    try {
      await createUser({ name: data.name, email: data.email, phone: data.phone, roles: [data.role], company_id: data.company_id || null, department: data.department || null })
      toast.success('User baru berhasil ditambahkan')
      setModalOpen(false); load()
    } catch { toast.error('Gagal menambahkan user') }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Manajemen User</h2>
          <p className="text-sm text-gray-500 mt-0.5">Kelola akun dan hak akses pengguna</p>
        </div>
        <Button variant="primary" icon={Plus} onClick={() => { reset({}); setModalOpen(true) }}>Tambah User</Button>
      </div>

      <div className="flex border-b border-gray-200">
        {['Daftar User', 'Role & Permission'].map((t, i) => (
          <button key={t} onClick={() => setTab(i)} className={`px-4 py-2.5 text-sm border-b-2 transition-colors ${tab === i ? 'border-brand text-brand font-medium' : 'border-transparent text-gray-500 hover:text-gray-800'}`}>{t}</button>
        ))}
      </div>

      {tab === 0 && (
        <Card>
          <CardBody className="p-0 sm:p-4">
            {users && users.length > 0 && (
              <div className="flex justify-end mb-2"><PageSizeSelector value={tc.perPage} onChange={tc.setPerPage} /></div>
            )}
            <Table>
              <Thead><Tr>
                <SortableTh label="Nama" sortKey="name" sortBy={tc.sortBy} sortDir={tc.sortDir} onSort={tc.toggleSort} />
                <Th>Email</Th><Th>Role</Th><Th>Perusahaan</Th><Th>Departemen</Th><Th>Status</Th><Th></Th>
              </Tr></Thead>
              <Tbody>
                {!users ? null : users.length === 0 ? <TableEmpty colSpan={7} /> : tc.paginated.map((u) => (
                  <Tr key={u.id}>
                    <Td>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-brand-light text-brand flex items-center justify-center text-[10px] font-semibold flex-shrink-0">{initials(u.name)}</div>
                        <span className="font-medium text-gray-900">{u.name}</span>
                      </div>
                    </Td>
                    <Td className="text-gray-500">{u.email}</Td>
                    <Td><Badge color={ROLE_COLORS[u.roles[0]]}>{ROLE_LABELS[u.roles[0]]}</Badge></Td>
                    <Td>{u.companyName || <span className="text-gray-300">-</span>}</Td>
                    <Td>{u.department || <span className="text-gray-300">-</span>}</Td>
                    <Td><Badge status={u.status} /></Td>
                    <Td>
                      <div className="flex gap-1">
                        <button className="p-1.5 text-gray-400 hover:text-brand hover:bg-gray-100 rounded-md"><Edit2 size={14} /></button>
                        <button className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-gray-100 rounded-md"><Trash2 size={14} /></button>
                      </div>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
            <Pagination page={tc.page} totalPages={tc.totalPages} onPageChange={tc.setPage} total={tc.total} perPage={tc.perPage} />
          </CardBody>
        </Card>
      )}

      {tab === 1 && <PermissionMatrix />}

      <Modal
        open={modalOpen} onClose={() => setModalOpen(false)} title="Tambah User Baru"
        footer={<>
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Batal</Button>
          <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(onSubmit)}>Simpan</Button>
        </>}
      >
        <form className="space-y-3" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Nama Lengkap" placeholder="Nama pengguna" {...register('name', { required: true })} />
            <Input label="Email" type="email" placeholder="email@domain.com" {...register('email', { required: true })} />
          </div>
          <Select label="Role" {...register('role', { required: true })}>
            <option value="">-- Pilih Role --</option>
            {assignableRoles.map((r) => <option key={r} value={r}>{ROLE_DEFINITIONS[r].label}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-3">
            <Select label="Perusahaan" {...register('company_id')}>
              <option value="">-- Pilih --</option>
              {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            <Input label="Departemen (staff dept)" placeholder="Nama departemen" {...register('department')} />
          </div>
          <div className="bg-blue-50 text-blue-700 text-xs rounded-lg p-3 ring-1 ring-blue-200">
            Password sementara akan dikirim ke email pengguna.
          </div>
        </form>
      </Modal>
    </div>
  )
}

function PermissionMatrix() {
  const [rolePerms, setRolePerms] = useState({})
  const [saving, setSaving] = useState(null)

  useEffect(() => {
    Promise.all(Object.keys(ROLE_DEFINITIONS).map((r) => getRolePermissions(r).then((p) => [r, p])))
      .then((entries) => setRolePerms(Object.fromEntries(entries)))
  }, [])

  async function togglePerm(role, permCode) {
    const current = rolePerms[role] || []
    const updated = current.includes(permCode) ? current.filter((p) => p !== permCode) : [...current, permCode]
    setRolePerms((prev) => ({ ...prev, [role]: updated }))
    setSaving(role)
    await updateRolePermissions(role, updated)
    setSaving(null)
  }

  const grouped = ALL_PERMISSIONS.reduce((acc, p) => {
    acc[p.group] = acc[p.group] || []
    acc[p.group].push(p)
    return acc
  }, {})

  return (
    <Card>
      <CardHeader><CardTitle>Setting Permission per Role</CardTitle></CardHeader>
      <CardBody className="space-y-6">
        {Object.entries(ROLE_DEFINITIONS).map(([roleKey, roleDef]) => {
          const Icon = ROLE_ICONS[roleKey]
          return (
            <div key={roleKey}>
              <div className="flex items-center gap-2 mb-3">
                <Icon size={16} className="text-gray-500" />
                <span className="text-sm font-semibold text-gray-800">{roleDef.label}</span>
                <Badge color={ROLE_COLORS[roleKey]}>{roleKey}</Badge>
                {saving === roleKey && <span className="text-xs text-gray-400">Menyimpan...</span>}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {ALL_PERMISSIONS.map((p) => (
                  <div key={p.code} className="flex items-center justify-between px-3 py-2 border border-gray-100 rounded-lg">
                    <span className="text-xs text-gray-600">{p.label}</span>
                    <Switch checked={(rolePerms[roleKey] || []).includes(p.code)} onChange={() => togglePerm(roleKey, p.code)} />
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </CardBody>
    </Card>
  )
}
