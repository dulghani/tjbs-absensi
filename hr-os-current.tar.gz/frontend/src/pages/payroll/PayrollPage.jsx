import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Plus, Eye, Download, Coins } from 'lucide-react'
import { getPayrolls, processPayroll, finalizePayroll, getCompanies } from '../../api/realService'
import { Card, CardHeader, CardTitle, CardBody, Select, Checkbox, Input, EmptyState } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import Modal from '../../components/ui/Modal'
import { Table, Thead, Tbody, Tr, Th, Td, TableEmpty, Pagination, PageSizeSelector, SortableTh } from '../../components/ui/Table'
import { useTableControls } from '../../hooks/useTableControls'
import { fCurrency, MONTHS_ID } from '../../lib/utils'
import { toast } from '../../components/ui/Toast'

export default function PayrollPage() {
  const [payrolls, setPayrolls] = useState(null)
  const [companies, setCompanies] = useState([])
  const [modalOpen, setModalOpen] = useState(false)
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm({ defaultValues: { period_year: 2025, period_month: 7 } })

  useEffect(() => { getCompanies().then(setCompanies); load() }, [])
  async function load() { setPayrolls(await getPayrolls()) }
  const tc = useTableControls(payrolls, { defaultSortBy: 'period_year', defaultSortDir: 'desc' })

  async function onSubmit(data) {
    try {
      await processPayroll({
        company_id: data.company_id, period_month: Number(data.period_month), period_year: Number(data.period_year),
        effective_work_days: data.effective_work_days ? Number(data.effective_work_days) : null,
      })
      toast.success('Proses penggajian dimulai')
      setModalOpen(false); load()
    } catch { toast.error('Gagal memproses penggajian') }
  }

  async function handleFinalize(id) {
    await finalizePayroll(id)
    toast.success('Payroll berhasil difinalisasi')
    load()
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Penggajian</h2>
          <p className="text-sm text-gray-500 mt-0.5">Proses dan kelola gaji karyawan outsourcing</p>
        </div>
        <Button variant="primary" icon={Plus} onClick={() => { reset({ period_year: 2025, period_month: 7 }); setModalOpen(true) }}>Proses Gaji Baru</Button>
      </div>

      <div className="bg-blue-50 text-blue-700 text-xs rounded-lg p-3 ring-1 ring-blue-200">
        Data gaji dihitung otomatis berdasarkan absensi, lembur, dan setting aturan per perusahaan.
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daftar Penggajian</CardTitle>
          {payrolls && payrolls.length > 0 && <PageSizeSelector value={tc.perPage} onChange={tc.setPerPage} />}
        </CardHeader>
        <CardBody className="p-0 sm:p-4">
          <Table>
            <Thead><Tr>
              <SortableTh label="Perusahaan" sortKey="companyName" sortBy={tc.sortBy} sortDir={tc.sortDir} onSort={tc.toggleSort} />
              <SortableTh label="Periode" sortKey="period_year" sortBy={tc.sortBy} sortDir={tc.sortDir} onSort={tc.toggleSort} />
              <Th>Karyawan</Th><Th>Total Bruto</Th><Th>Total Neto</Th><Th>Status</Th><Th></Th>
            </Tr></Thead>
            <Tbody>
              {!payrolls ? null : payrolls.length === 0 ? <TableEmpty colSpan={7} /> : tc.paginated.map((p) => (
                <Tr key={p.id}>
                  <Td className="font-medium text-gray-900">{p.companyName}</Td>
                  <Td>{MONTHS_ID[p.period_month - 1]} {p.period_year}</Td>
                  <Td>{p.employees} orang</Td>
                  <Td className="font-mono text-xs">{fCurrency(p.totalGross)}</Td>
                  <Td className="font-mono text-xs">{fCurrency(p.totalNet)}</Td>
                  <Td><Badge status={p.status} /></Td>
                  <Td>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-md"><Eye size={14} /></button>
                      <button className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-md"><Download size={14} /></button>
                      {p.status === 'processing' && (
                        <Button size="sm" variant="primary" onClick={() => handleFinalize(p.id)}>Finalisasi</Button>
                      )}
                    </div>
                  </Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
          <Pagination page={tc.page} totalPages={tc.totalPages} onPageChange={tc.setPage} total={tc.total} perPage={tc.perPage} />
        </CardBody>
      </Card>

      <Modal
        open={modalOpen} onClose={() => setModalOpen(false)} title="Proses Penggajian Baru" size="sm"
        footer={<>
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Batal</Button>
          <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(onSubmit)}>Mulai Proses</Button>
        </>}
      >
        <form className="space-y-3" onSubmit={handleSubmit(onSubmit)}>
          <Select label="Perusahaan" {...register('company_id', { required: true })}>
            <option value="">-- Pilih --</option>
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-3">
            <Select label="Periode Bulan" {...register('period_month')}>
              {MONTHS_ID.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
            </Select>
            <Select label="Tahun" {...register('period_year')}>
              {[2024, 2025, 2026].map((y) => <option key={y} value={y}>{y}</option>)}
            </Select>
          </div>
          <Input
            label="Hari Kerja Efektif Bulan Ini" type="number" placeholder="mis. 25" min={1} max={31}
            {...register('effective_work_days')}
            hint="Jumlah hari kerja riil bulan ini (dikurangi libur nasional dll) — jadi acuan hitung potongan absen. Beda tiap bulan, isi manual."
          />
          <div className="bg-amber-50 text-amber-700 text-xs rounded-lg p-3 ring-1 ring-amber-200">
            Sistem akan menarik data absensi & lembur yang sudah dikonfirmasi untuk periode ini.
          </div>
          <div className="space-y-1">
            <Checkbox label="Hitung lembur otomatis" defaultChecked />
            <Checkbox label="Potong komponen wajib (BPJS, dll)" defaultChecked />
            <Checkbox label="Mode preview (tidak simpan)" />
          </div>
        </form>
      </Modal>
    </div>
  )
}
