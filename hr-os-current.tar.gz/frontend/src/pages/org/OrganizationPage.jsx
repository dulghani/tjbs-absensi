import { useEffect, useState } from 'react'
import { ChevronRight, ChevronDown, Building2, Network, Users, GitBranch, Plus } from 'lucide-react'
import { getCompanies, getOrgTree, createDepartment, createDivision } from '../../api/realService'
import { Card, CardHeader, CardTitle, CardBody, Select, Input } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Modal from '../../components/ui/Modal'
import { useForm } from 'react-hook-form'
import { toast } from '../../components/ui/Toast'
import { cn } from '../../lib/utils'

const TYPE_ICON = { company: Building2, division: GitBranch, department: Network, section: Network, line: Users }
const TYPE_LABEL = { company: 'Perusahaan', division: 'Divisi', department: 'Departemen', section: 'Section', line: 'Line' }
const TYPE_COLOR = { company: 'text-brand bg-brand-light', division: 'text-purple-600 bg-purple-50', department: 'text-amber-600 bg-amber-50', section: 'text-pink-600 bg-pink-50', line: 'text-green-600 bg-green-50' }

function TreeNode({ node, depth = 0 }) {
  const [open, setOpen] = useState(depth < 2)
  const hasChildren = node.children?.length > 0
  const Icon = TYPE_ICON[node.type] || Network

  return (
    <div>
      <div
        className={cn('flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-gray-50 cursor-pointer group', depth > 0 && 'ml-5 border-l border-gray-100 pl-3')}
        onClick={() => hasChildren && setOpen((o) => !o)}
      >
        {hasChildren ? (
          open ? <ChevronDown size={14} className="text-gray-400 flex-shrink-0" /> : <ChevronRight size={14} className="text-gray-400 flex-shrink-0" />
        ) : <span className="w-3.5" />}
        <div className={cn('w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0', TYPE_COLOR[node.type])}>
          <Icon size={12} />
        </div>
        <span className="text-sm text-gray-800 font-medium">{node.name}</span>
        <span className="text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded">{TYPE_LABEL[node.type]}</span>
        {node.capacity && <span className="text-[10px] text-gray-400 ml-auto">Kapasitas: {node.capacity}</span>}
      </div>
      {open && hasChildren && (
        <div>{node.children.map((c) => <TreeNode key={c.id} node={c} depth={depth + 1} />)}</div>
      )}
    </div>
  )
}

export default function OrganizationPage() {
  const [companies, setCompanies] = useState([])
  const [selectedId, setSelectedId] = useState('')
  const [tree, setTree] = useState(null)
  const [modalType, setModalType] = useState(null)
  const { register, handleSubmit, reset, formState: { isSubmitting } } = useForm()

  useEffect(() => { getCompanies().then((c) => { setCompanies(c); if (c.length) setSelectedId(c[0].id) }) }, [])
  useEffect(() => { if (selectedId) loadTree() }, [selectedId])

  async function loadTree() { setTree(await getOrgTree(selectedId)) }

  async function onSubmit(data) {
    try {
      if (modalType === 'division') await createDivision(selectedId, data)
      else await createDepartment(selectedId, data)
      toast.success(`${modalType === 'division' ? 'Divisi' : 'Departemen'} berhasil ditambahkan`)
      setModalType(null)
      loadTree()
    } catch { toast.error('Gagal menyimpan') }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Struktur Organisasi</h2>
          <p className="text-sm text-gray-500 mt-0.5">Company → Division → Department → Section → Line</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" icon={Plus} onClick={() => { reset({}); setModalType('division') }}>Divisi</Button>
          <Button variant="primary" icon={Plus} onClick={() => { reset({}); setModalType('department') }}>Departemen</Button>
        </div>
      </div>

      <Card>
        <CardBody className="pb-3">
          <Select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="max-w-xs">
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
        </CardBody>
      </Card>

      <Card>
        <CardHeader><CardTitle>Hierarki Organisasi</CardTitle></CardHeader>
        <CardBody>
          {tree ? <TreeNode node={tree} /> : <p className="text-sm text-gray-400 text-center py-8">Memuat...</p>}
        </CardBody>
      </Card>

      <Modal
        open={!!modalType} onClose={() => setModalType(null)}
        title={`Tambah ${modalType === 'division' ? 'Divisi' : 'Departemen'} Baru`}
        size="sm"
        footer={<>
          <Button variant="secondary" onClick={() => setModalType(null)}>Batal</Button>
          <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(onSubmit)}>Simpan</Button>
        </>}
      >
        <form className="space-y-3" onSubmit={handleSubmit(onSubmit)}>
          <Input label="Kode" placeholder="DEPT-001" {...register('code', { required: true })} />
          <Input label="Nama" placeholder={modalType === 'division' ? 'Nama divisi' : 'Nama departemen'} {...register('name', { required: true })} />
        </form>
      </Modal>
    </div>
  )
}
