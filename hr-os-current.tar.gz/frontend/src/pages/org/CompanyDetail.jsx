import { useEffect, useState } from 'react'
import { Save, Plus, Trash2, Zap } from 'lucide-react'
import { getWorkSettings, updateWorkSettings, getSalaryComponents, createSalaryComponent, deleteSalaryComponent } from '../../api/realService'
import { Card, CardHeader, CardTitle, CardBody, Input, Select } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import { Table, Thead, Tbody, Tr, Th, Td, TableEmpty } from '../../components/ui/Table'
import { fCurrency, cn } from '../../lib/utils'
import { toast } from '../../components/ui/Toast'
import Modal from '../../components/ui/Modal'
import { useForm } from 'react-hook-form'

const TABS = ['Jam Kerja', 'Aturan Lembur', 'Komponen Gaji']
const DAYS = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min']

// Tipe kalkulasi yang nilainya dihitung OTOMATIS dari data absensi + rate "Upah Per Hari"
// saat proses payroll — jadi form tambah komponen tidak perlu minta input "Nilai" untuk ini.
const AUTO_CALC_TYPES = ['attendance_earning', 'overtime_regular', 'absence_deduction', 'early_leave_deduction']

const CALC_TYPE_LABELS = {
  fixed: 'Nominal Tetap', percentage: 'Persentase', per_hari: 'Per Hari Hadir',
  daily_wage_rate: 'Rate Upah Per Hari', overtime_holiday: 'Rate Lembur Merah/jam',
  attendance_earning: 'Otomatis: Kehadiran', overtime_regular: 'Otomatis: Lembur Biasa',
  absence_deduction: 'Otomatis: Potongan Absen', early_leave_deduction: 'Otomatis: Potongan Izin Pulang',
}

// 5 komponen standar model upah harian sesuai spesifikasi — tombol "Setup Cepat" bikin
// semuanya sekaligus supaya tidak perlu tambah manual satu-satu. Rate (Upah Per Hari,
// Lembur Merah) dibuat placeholder 0, WAJIB diedit manual sesuai perusahaan masing-masing.
const QUICK_SETUP_COMPONENTS = [
  { name: 'Upah Per Hari', type: 'earning', calc: 'daily_wage_rate', value: 0 },
  { name: 'Kehadiran', type: 'earning', calc: 'attendance_earning', value: 0 },
  { name: 'Lembur Biasa', type: 'earning', calc: 'overtime_regular', value: 0 },
  { name: 'Lembur Merah', type: 'earning', calc: 'overtime_holiday', value: 0 },
  { name: 'Potongan Absen', type: 'deduction', calc: 'absence_deduction', value: 0 },
  { name: 'Potongan Izin Pulang', type: 'deduction', calc: 'early_leave_deduction', value: 0 },
]

// Dipakai kalau perusahaan belum pernah punya company_work_settings sama sekali
// (setup pertama kali) — supaya form tetap bisa dibuka & diisi, bukan blank.
const DEFAULT_SETTINGS = {
  workStart: '08:00', workEnd: '17:00', breakMin: 60,
  workDays: [1, 1, 1, 1, 1, 0, 0], lateTolerance: 15,
  otMinMin: 30, otMethod: 'per_hour', tiers: [], dailyHoursOverride: {},
}

export default function CompanyDetail({ company }) {
  const [tab, setTab] = useState(0)
  const [settings, setSettings] = useState(undefined) // undefined = belum load, null = load selesai tapi kosong
  const [components, setComponents] = useState([])
  const [saving, setSaving] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const { register, handleSubmit, reset, watch, formState: { isSubmitting } } = useForm()
  const watchCalc = watch('calc')

  const quickSetupDone = QUICK_SETUP_COMPONENTS.every((qc) => components.some((c) => c.calc === qc.calc))

  useEffect(() => { load() }, [company])
  async function load() {
    const [ws, sc] = await Promise.all([getWorkSettings(company.id), getSalaryComponents(company.id)])
    setSettings(ws) // bisa null kalau memang belum pernah diisi — itu valid, bukan error
    setComponents(sc)
  }

  async function handleSaveWorkHours(form) {
    setSaving(true)
    try {
      await updateWorkSettings(company.id, form)
      toast.success('Pengaturan jam kerja berhasil disimpan')
      load() // refresh supaya banner "belum ada pengaturan" hilang setelah setup pertama
    } finally { setSaving(false) }
  }

  async function handleAddComponent(data) {
    try {
      const value = data.value !== undefined && data.value !== '' ? Number(data.value) : null
      await createSalaryComponent(company.id, { ...data, value, taxable: data.type === 'earning' })
      toast.success('Komponen gaji ditambahkan')
      setModalOpen(false)
      load()
    } catch { toast.error('Gagal menambahkan komponen') }
  }

  async function handleQuickSetup() {
    try {
      const toCreate = QUICK_SETUP_COMPONENTS.filter((qc) => !components.some((c) => c.calc === qc.calc))
      for (const qc of toCreate) {
        await createSalaryComponent(company.id, { name: qc.name, type: qc.type, calc: qc.calc, value: qc.value, taxable: false })
      }
      toast.success(`${toCreate.length} komponen standar ditambahkan. Jangan lupa isi rate "Upah Per Hari" & "Lembur Merah".`)
      load()
    } catch { toast.error('Gagal setup komponen') }
  }

  async function handleDeleteComponent(id) {
    await deleteSalaryComponent(id)
    toast.success('Komponen dihapus')
    load()
  }

  if (settings === undefined) return null // masih loading, ini beda dari "null" (memang kosong)
  const effectiveSettings = settings || DEFAULT_SETTINGS
  const isFirstSetup = settings === null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Detail Perusahaan: {company.name}</CardTitle>
      </CardHeader>
      <div className="flex border-b border-gray-100 px-4 overflow-x-auto">
        {TABS.map((t, i) => (
          <button
            key={t}
            onClick={() => setTab(i)}
            className={`px-3.5 py-2.5 text-sm whitespace-nowrap border-b-2 transition-colors ${tab === i ? 'border-brand text-brand font-medium' : 'border-transparent text-gray-500 hover:text-gray-800'}`}
          >{t}</button>
        ))}
      </div>
      <CardBody>
        {isFirstSetup && (
          <div className="bg-amber-50 text-amber-700 text-xs rounded-lg p-3 ring-1 ring-amber-200 mb-4">
            Belum ada aturan kerja untuk perusahaan ini. Isi form di bawah lalu simpan untuk mengaktifkan —
            tanpa ini, semua karyawan akan tercatat "Hari Libur" alih-alih "Hadir"/"Absen" saat kalkulasi absensi berjalan.
          </div>
        )}
        {tab === 0 && (
          <WorkHoursForm settings={effectiveSettings} isFirstSetup={isFirstSetup} onSave={handleSaveWorkHours} saving={saving} />
        )}
        {tab === 1 && (
          <OvertimeRulesView settings={effectiveSettings} />
        )}
        {tab === 2 && (
          <div>
            <div className="flex justify-between items-center mb-3 gap-2 flex-wrap">
              <p className="text-xs text-gray-400">Model upah harian: Upah Per Hari jadi basis hitung Kehadiran, Lembur Biasa, dan Potongan Absen otomatis.</p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" icon={Zap} onClick={handleQuickSetup} disabled={quickSetupDone}>
                  {quickSetupDone ? 'Sudah Di-setup' : 'Setup Cepat (5 Komponen Standar)'}
                </Button>
                <Button variant="primary" size="sm" icon={Plus} onClick={() => { reset({ type: 'earning', calc: 'fixed', value: 0 }); setModalOpen(true) }}>Tambah Manual</Button>
              </div>
            </div>
            <Table>
              <Thead><Tr>
                <Th>Nama Komponen</Th><Th>Tipe</Th><Th>Perhitungan</Th><Th>Nilai</Th><Th>Kena Pajak</Th><Th></Th>
              </Tr></Thead>
              <Tbody>
                {components.length === 0 ? <TableEmpty colSpan={6} /> : components.map((s) => (
                  <Tr key={s.id}>
                    <Td className="font-medium text-gray-900">{s.name}</Td>
                    <Td><Badge color={s.type === 'earning' ? 'bg-green-50 text-green-700 ring-green-200' : s.type === 'deduction' ? 'bg-red-50 text-red-700 ring-red-200' : 'bg-gray-50 text-gray-500 ring-gray-200'}>{s.type === 'earning' ? 'Pendapatan' : s.type === 'deduction' ? 'Potongan' : 'Referensi'}</Badge></Td>
                    <Td className="text-xs">{CALC_TYPE_LABELS[s.calc] || s.calc}</Td>
                    <Td>{AUTO_CALC_TYPES.includes(s.calc) ? <span className="text-gray-400 italic">otomatis</span> : (s.calc === 'percentage' ? `${s.value}%` : fCurrency(s.value))}</Td>
                    <Td>{s.taxable ? 'Ya' : 'Tidak'}</Td>
                    <Td><button onClick={() => handleDeleteComponent(s.id)} className="text-gray-300 hover:text-red-500"><Trash2 size={14} /></button></Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </div>
        )}
      </CardBody>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Tambah Komponen Gaji" size="sm"
        footer={<>
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Batal</Button>
          <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(handleAddComponent)}>Simpan</Button>
        </>}
      >
        <form className="space-y-3" onSubmit={handleSubmit(handleAddComponent)}>
          <Input label="Nama Komponen" placeholder="Tunjangan Kehadiran" {...register('name', { required: true })} />
          <div className="grid grid-cols-2 gap-3">
            <Select label="Tipe" {...register('type')}>
              <option value="earning">Pendapatan</option>
              <option value="deduction">Potongan</option>
            </Select>
            <Select label="Cara Hitung" {...register('calc')}>
              <optgroup label="Umum">
                <option value="fixed">Nominal Tetap</option>
                <option value="percentage">Persentase (dari Upah x Hari Efektif)</option>
                <option value="per_hari">Per Hari Hadir</option>
              </optgroup>
              <optgroup label="Model Upah Harian">
                <option value="daily_wage_rate">Rate: Upah Per Hari</option>
                <option value="overtime_holiday">Rate: Lembur Merah /jam</option>
                <option value="attendance_earning">Otomatis: Kehadiran (upah x hari hadir)</option>
                <option value="overtime_regular">Otomatis: Lembur Biasa (upah/7 x jam lembur)</option>
                <option value="absence_deduction">Otomatis: Potongan Absen</option>
                <option value="early_leave_deduction">Otomatis: Potongan Izin Pulang</option>
              </optgroup>
            </Select>
          </div>
          {!AUTO_CALC_TYPES.includes(watchCalc) && (
            <Input
              label={watchCalc === 'daily_wage_rate' ? 'Upah Per Hari (Rp)' : watchCalc === 'overtime_holiday' ? 'Rate Lembur Merah per Jam (Rp)' : watchCalc === 'percentage' ? 'Persentase (%)' : 'Nilai (Rp)'}
              type="number" placeholder="0" {...register('value', { required: true })}
            />
          )}
          {AUTO_CALC_TYPES.includes(watchCalc) && (
            <p className="text-xs text-gray-400 bg-gray-50 rounded-lg p-2.5">Nilai dihitung otomatis dari data absensi + rate "Upah Per Hari" saat proses payroll. Tidak perlu diisi manual.</p>
          )}
        </form>
      </Modal>
    </Card>
  )
}

function WorkHoursForm({ settings, isFirstSetup, onSave, saving }) {
  const { register, handleSubmit, watch } = useForm({ defaultValues: settings })
  const [workDays, setWorkDays] = useState(settings.workDays)
  // dailyOverrides: { "6": { start_time, end_time } } — hanya diisi untuk hari yang
  // jam kerjanya BEDA dari jam global (mis. Sabtu 07:00-12:00 kalau global 07:00-16:00).
  const [dailyOverrides, setDailyOverrides] = useState(settings.dailyHoursOverride || {})
  const globalStart = watch('workStart')
  const globalEnd = watch('workEnd')
  const today = new Date().toISOString().slice(0, 10)
  const nextMonthFirst = (() => {
    const d = new Date()
    d.setMonth(d.getMonth() + 1, 1)
    return d.toISOString().slice(0, 10)
  })()

  function toggleDay(i) {
    setWorkDays((prev) => prev.map((v, idx) => (idx === i ? (v === 1 ? 0 : 1) : v)))
  }

  function toggleCustomHours(dayIso, checked) {
    setDailyOverrides((prev) => {
      const next = { ...prev }
      if (checked) next[dayIso] = { start_time: globalStart, end_time: globalEnd }
      else delete next[dayIso]
      return next
    })
  }

  function updateOverrideTime(dayIso, field, value) {
    setDailyOverrides((prev) => ({ ...prev, [dayIso]: { ...prev[dayIso], [field]: value } }))
  }

  function submit(form) {
    onSave({ ...form, workDays, daily_hours_override: dailyOverrides })
  }

  return (
    <form className="space-y-4" onSubmit={handleSubmit(submit)}>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Input label="Jam Masuk (Default)" type="time" {...register('workStart')} />
        <Input label="Jam Pulang (Default)" type="time" {...register('workEnd')} />
        <Input label="Istirahat (menit)" type="number" {...register('breakMin')} />
        <Input label="Toleransi Telat (menit)" type="number" {...register('lateTolerance')} />
      </div>

      <div>
        <label className="block text-xs font-medium text-gray-600 mb-2">Hari Kerja & Jam Khusus</label>
        <div className="border border-gray-200 rounded-lg divide-y divide-gray-100">
          {DAYS.map((d, i) => {
            const dayIso = i + 1 // 1=Senin..7=Minggu
            const active = workDays[i] === 1
            const hasOverride = !!dailyOverrides[dayIso]
            return (
              <div key={d} className={cn('flex items-center gap-3 px-3 py-2', !active && 'opacity-40')}>
                <label className="flex items-center gap-2 w-20 flex-shrink-0 cursor-pointer">
                  <input type="checkbox" checked={active} onChange={() => toggleDay(i)} className="w-4 h-4 rounded border-gray-300 text-brand" />
                  <span className="text-xs font-medium text-gray-700">{d}</span>
                </label>
                {active && (
                  <>
                    <label className="flex items-center gap-1.5 text-xs text-gray-500 cursor-pointer">
                      <input type="checkbox" checked={hasOverride} onChange={(e) => toggleCustomHours(dayIso, e.target.checked)} className="w-3.5 h-3.5 rounded border-gray-300 text-amber-500" />
                      Jam khusus
                    </label>
                    {hasOverride ? (
                      <div className="flex items-center gap-1.5">
                        <input type="time" value={dailyOverrides[dayIso]?.start_time || ''} onChange={(e) => updateOverrideTime(dayIso, 'start_time', e.target.value)} className="text-xs px-2 py-1 border border-gray-300 rounded-md" />
                        <span className="text-gray-400">–</span>
                        <input type="time" value={dailyOverrides[dayIso]?.end_time || ''} onChange={(e) => updateOverrideTime(dayIso, 'end_time', e.target.value)} className="text-xs px-2 py-1 border border-gray-300 rounded-md" />
                      </div>
                    ) : (
                      <span className="text-xs text-gray-400">{globalStart}–{globalEnd} (default)</span>
                    )}
                  </>
                )}
              </div>
            )
          })}
        </div>
        <p className="text-[11px] text-gray-400 mt-1.5">Contoh: centang "Jam khusus" di Sabtu, atur 07:00–12:00 supaya hari itu cuma 5 jam kerja.</p>
      </div>

      <Input
        label="Berlaku Mulai Tanggal" type="date"
        defaultValue={isFirstSetup ? today : nextMonthFirst}
        {...register('effective_date')}
        hint={isFirstSetup ? 'Setup pertama — default hari ini supaya langsung aktif.' : 'Perubahan ke pengaturan yang sudah ada default berlaku bulan depan, supaya payroll periode berjalan tidak terpengaruh. Bisa diubah manual kalau perlu.'}
      />
      <div className="flex justify-end">
        <Button variant="primary" icon={Save} type="submit" loading={saving}>Simpan Perubahan</Button>
      </div>
    </form>
  )
}

function OvertimeRulesView({ settings }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Input label="Minimal Durasi Lembur (menit)" defaultValue={settings.otMinMin} type="number" />
        <Select label="Metode Perhitungan" defaultValue={settings.otMethod}>
          <option value="per_hour">Per Jam</option>
          <option value="per_15min">Per 15 Menit</option>
          <option value="flat">Flat</option>
        </Select>
      </div>
      <div>
        <p className="text-sm font-medium text-gray-700 mb-2">Tier Multiplier Lembur</p>
        <Table>
          <Thead><Tr><Th>Tipe Hari</Th><Th>Jam Ke (dari)</Th><Th>Jam Ke (sampai)</Th><Th>Multiplier</Th></Tr></Thead>
          <Tbody>
            {settings.tiers.map((t, i) => (
              <Tr key={i}>
                <Td className="capitalize">{t.dayType === 'weekday' ? 'Hari Kerja' : t.dayType === 'weekend' ? 'Akhir Pekan' : 'Hari Libur'}</Td>
                <Td>{t.from}</Td>
                <Td>{t.to ?? '∞'}</Td>
                <Td className="font-medium text-brand">{t.multiplier}x</Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </div>
      <div className="flex justify-end">
        <Button variant="primary" icon={Save}>Simpan Perubahan</Button>
      </div>
    </div>
  )
}
