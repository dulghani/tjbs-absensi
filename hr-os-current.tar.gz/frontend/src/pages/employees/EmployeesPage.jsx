import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { Plus, Search, Eye, Edit2, Trash2 } from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { getEmployeesPaginated, getCompanies, createEmployee, updateEmployee, deleteEmployee } from '../../api/realService'
import { Card, CardBody, Input, Select } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import Modal, { ConfirmModal } from '../../components/ui/Modal'
import { Table, Thead, Tbody, Tr, Th, Td, TableEmpty, Pagination, PageSizeSelector } from '../../components/ui/Table'
import { fDate } from '../../lib/utils'
import { toast } from '../../components/ui/Toast'

export default function EmployeesPage() {
  const user = useAuthStore((s) => s.user)
  const role = user?.roles?.[0]
  const isMultiCompany = ['coordinator', 'field_officer'].includes(role)
  const canEdit = ['coordinator', 'field_officer', 'hrd'].includes(role)

  const [employees, setEmployees] = useState(null)
  const [total, setTotal] = useState(0)
  const [companies, setCompanies] = useState([])
  const [search, setSearch] = useState('')
  const [searchParams] = useSearchParams()
  const companyFromUrl = searchParams.get('company')
  const [filterCompany, setFilterCompany] = useState(companyFromUrl || (isMultiCompany ? 'all' : user.company_id))
  const [filterStatus, setFilterStatus] = useState('all')
  const [page, setPage] = useState(1)
  const [perPage, setPerPage] = useState(25)
  const [modalOpen, setModalOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm()

  useEffect(() => { getCompanies().then(setCompanies) }, [])
  // Filter berubah -> balik ke halaman 1, biar tidak nyangkut di halaman kosong.
  useEffect(() => { setPage(1) }, [search, filterCompany, filterStatus, perPage])
  useEffect(() => { load() }, [search, filterCompany, filterStatus, page, perPage])

  async function load() {
    const result = await getEmployeesPaginated(
      { search, company_id: filterCompany, status: filterStatus, department: role === 'staff_dept' ? user.department : undefined },
      page, perPage
    )
    setEmployees(result.data)
    setTotal(result.total)
  }

  function openCreate() { setEditing(null); reset({ company_id: !isMultiCompany ? user.company_id : '' }); setModalOpen(true) }
  function openEdit(e) { setEditing(e); reset(e); setModalOpen(true) }

  async function onSubmit(data) {
    try {
      if (editing) { await updateEmployee(editing.id, data); toast.success('Data karyawan diperbarui') }
      else { await createEmployee({ ...data, nik: data.nik || String(Math.floor(Math.random() * 900000) + 100000) }); toast.success('Karyawan baru ditambahkan') }
      setModalOpen(false); load()
    } catch { toast.error('Gagal menyimpan data') }
  }

  async function handleDelete() {
    await deleteEmployee(deleteTarget.id)
    toast.success('Data karyawan dihapus')
    setDeleteTarget(null)
    load()
  }

  const totalPages = Math.max(1, Math.ceil(total / perPage))

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Data Karyawan</h2>
          <p className="text-sm text-gray-500 mt-0.5">{total} karyawan ditemukan</p>
        </div>
        {canEdit && <Button variant="primary" icon={Plus} onClick={openCreate}>Tambah Karyawan</Button>}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            placeholder="Cari nama/NIK..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg outline-none focus:border-brand bg-white"
          />
        </div>
        {isMultiCompany && (
          <select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
            <option value="all">Semua Perusahaan</option>
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
          <option value="all">Semua Status</option>
          <option value="active">Aktif</option>
          <option value="inactive">Nonaktif</option>
        </select>
        <div className="ml-auto">
          <PageSizeSelector value={perPage} onChange={setPerPage} />
        </div>
      </div>

      <Card>
        <CardBody className="p-0 sm:p-4">
          <Table>
            <Thead>
              <Tr>
                <Th>NIK</Th><Th>Nama</Th>
                {isMultiCompany && <Th>Perusahaan</Th>}
                <Th>Departemen</Th><Th>Jabatan</Th><Th>Tgl Masuk</Th><Th>Status</Th><Th></Th>
              </Tr>
            </Thead>
            <Tbody>
              {!employees ? null : employees.length === 0 ? (
                <TableEmpty colSpan={8} message="Tidak ada data karyawan" />
              ) : employees.map((emp) => (
                <Tr key={emp.id}>
                  <Td className="font-mono text-xs">{emp.nik}</Td>
                  <Td className="font-medium text-gray-900">{emp.name}</Td>
                  {isMultiCompany && <Td><Badge color="bg-blue-50 text-blue-700 ring-blue-200">{emp.companyName}</Badge></Td>}
                  <Td>{emp.department}</Td>
                  <Td>{emp.position}</Td>
                  <Td>{fDate(emp.joinDate)}</Td>
                  <Td><Badge status={emp.status} /></Td>
                  <Td>
                    <div className="flex gap-1">
                      <button className="p-1.5 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-md"><Eye size={14} /></button>
                      {canEdit && <button onClick={() => openEdit(emp)} className="p-1.5 text-gray-400 hover:text-brand hover:bg-gray-100 rounded-md"><Edit2 size={14} /></button>}
                      {canEdit && <button onClick={() => setDeleteTarget(emp)} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-gray-100 rounded-md"><Trash2 size={14} /></button>}
                    </div>
                  </Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
          <Pagination page={page} totalPages={totalPages} onPageChange={setPage} total={total} perPage={perPage} />
        </CardBody>
      </Card>

      <Modal
        open={modalOpen} onClose={() => setModalOpen(false)} size="lg"
        title={editing ? 'Edit Data Karyawan' : 'Tambah Data Karyawan'}
        footer={<>
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Batal</Button>
          <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(onSubmit)}>Simpan</Button>
        </>}
      >
        <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid grid-cols-2 gap-3">
            <Input label="NIK" placeholder="Auto generate jika kosong" {...register('nik')} />
            <Input label="Nama Lengkap" placeholder="Nama sesuai KTP" {...register('name', { required: true })} error={errors.name && 'Wajib diisi'} />
          </div>
          {isMultiCompany && (
            <Select label="Perusahaan" {...register('company_id', { required: true })}>
              <option value="">-- Pilih Perusahaan --</option>
              {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
          )}
          <div className="grid grid-cols-2 gap-3">
            <Input label="Departemen" placeholder="Nama departemen" {...register('department', { required: true })} />
            <Input label="Line/Unit" placeholder="Opsional" {...register('line')} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Jabatan" placeholder="Posisi/jabatan" {...register('position', { required: true })} />
            <Input label="Tgl Mulai Kerja" type="date" {...register('joinDate', { required: true })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Select label="Status Kepegawaian" {...register('employmentStatus')}>
              <option value="permanent">Tetap</option>
              <option value="contract">Kontrak</option>
              <option value="probation">Percobaan</option>
              <option value="temporary">Harian/Lepas</option>
            </Select>
            <Input label="No. HP" placeholder="08xx-xxxx-xxxx" {...register('phone')} />
          </div>
          <Input label="No. KTP" placeholder="16 digit NIK KTP" {...register('ktp')} />
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1.5">Alamat</label>
            <textarea rows={2} className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg outline-none focus:border-brand resize-none" placeholder="Alamat lengkap" {...register('address')} />
          </div>
        </form>
      </Modal>

      <ConfirmModal
        open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={handleDelete} danger
        title="Hapus Karyawan" message={`Apakah Anda yakin ingin menghapus data ${deleteTarget?.name}? Tindakan ini tidak dapat dibatalkan.`}
      />
    </div>
  )
}
