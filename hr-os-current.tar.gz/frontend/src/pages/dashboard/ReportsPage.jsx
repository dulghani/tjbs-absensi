import { Users, Clock, Coins, CalendarCheck, Eye, Download } from 'lucide-react'
import { Card } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'

const REPORTS = [
  { icon: Users, label: 'Laporan Karyawan', desc: 'Data lengkap karyawan per perusahaan', color: 'bg-blue-50 text-blue-600' },
  { icon: Clock, label: 'Laporan Lembur', desc: 'Rekap lembur per periode', color: 'bg-amber-50 text-amber-600' },
  { icon: Coins, label: 'Laporan Gaji', desc: 'Slip gaji dan rekapitulasi', color: 'bg-green-50 text-green-600' },
  { icon: CalendarCheck, label: 'Laporan Absensi', desc: 'Kehadiran per karyawan/departemen', color: 'bg-purple-50 text-purple-600' },
]

export default function ReportsPage() {
  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Laporan</h2>
        <p className="text-sm text-gray-500 mt-0.5">Export dan cetak laporan operasional</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {REPORTS.map((r) => (
          <Card key={r.label} className="p-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${r.color}`}>
              <r.icon size={18} />
            </div>
            <p className="text-sm font-semibold text-gray-900 mb-1">{r.label}</p>
            <p className="text-xs text-gray-400 mb-4">{r.desc}</p>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" icon={Eye}>Preview</Button>
              <Button variant="secondary" size="sm" icon={Download}>Export</Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
