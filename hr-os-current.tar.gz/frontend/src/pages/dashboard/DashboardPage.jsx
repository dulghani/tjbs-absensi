import { useEffect, useState } from 'react'
import { Building2, Users, Clock, Coins, TrendingUp, Calendar, ArrowUpRight } from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { getDashboardStats, getOvertimeRequests, getPayrolls } from '../../api/realService'
import { Card, CardHeader, CardTitle, CardBody, Skeleton } from '../../components/ui/Primitives'
import Badge from '../../components/ui/Badge'
import { fDate, fRelative, ROLE_LABELS } from '../../lib/utils'
import { Link } from 'react-router-dom'

function StatCard({ label, value, sub, icon: Icon, color = 'brand', progress }) {
  const colorMap = {
    brand: 'bg-brand-light text-brand',
    green: 'bg-green-50 text-green-600',
    amber: 'bg-amber-50 text-amber-600',
    purple: 'bg-purple-50 text-purple-600',
  }
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${colorMap[color]}`}>
          <Icon size={17} />
        </div>
      </div>
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className="text-2xl font-semibold text-gray-900">{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
    </Card>
  )
}

export default function DashboardPage() {
  const user = useAuthStore((s) => s.user)
  const company = useAuthStore((s) => s.company)
  const [stats, setStats] = useState(null)
  const [recentOT, setRecentOT] = useState([])
  const [payrolls, setPayrolls] = useState([])
  const role = user?.roles?.[0]
  const isMultiCompany = ['coordinator', 'field_officer'].includes(role)

  useEffect(() => {
    getDashboardStats(user).then(setStats)
    getOvertimeRequests({ company_id: isMultiCompany ? 'all' : user.company_id }).then((r) => setRecentOT(r.slice(0, 4)))
    if (role === 'coordinator') getPayrolls().then(setPayrolls)
  }, [user])

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Selamat datang, {user?.name?.split(' ')[0]} 👋</h2>
          <p className="text-sm text-gray-500 mt-0.5">
            {isMultiCompany ? 'Ringkasan data seluruh outsourcing' : `Ringkasan ${company?.name || ''}`}
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-gray-500 bg-white border border-gray-200 rounded-lg px-3 py-2">
          <Calendar size={13} /> {fDate(new Date(), 'EEEE, d MMMM yyyy')}
        </div>
      </div>

      {!stats ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{[1,2,3,4].map(i => <Skeleton key={i} className="h-28" />)}</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {isMultiCompany && (
            <StatCard label="Total Perusahaan" value={stats.totalCompanies} sub="Semua aktif" icon={Building2} color="brand" />
          )}
          <StatCard label="Total Karyawan" value={stats.totalEmployees} sub="Karyawan aktif" icon={Users} color="green" />
          <StatCard label="Pengajuan Lembur" value={stats.pendingOvertime} sub={`${stats.pendingOvertime} menunggu konfirmasi`} icon={Clock} color="amber" />
          {role === 'coordinator' && (
            <StatCard label="Penggajian Berjalan" value={stats.payrollProcessing + stats.payrollDraft} sub={`${stats.payrollFinalized} sudah final`} icon={Coins} color="purple" />
          )}
        </div>
      )}

      <div className={`grid gap-4 ${role === 'coordinator' ? 'lg:grid-cols-2' : 'grid-cols-1'}`}>
        <Card>
          <CardHeader>
            <CardTitle>Pengajuan Lembur Terbaru</CardTitle>
            <Link to="/overtime" className="text-xs text-brand hover:underline flex items-center gap-0.5">Lihat semua <ArrowUpRight size={12} /></Link>
          </CardHeader>
          <CardBody className="p-0">
            {recentOT.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-8">Belum ada pengajuan lembur</p>
            ) : (
              <div className="divide-y divide-gray-50">
                {recentOT.map((ot) => (
                  <div key={ot.id} className="px-4 py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-gray-900 font-mono">{ot.no}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{ot.department} · {ot.items.length} karyawan · {fDate(ot.date)}</p>
                    </div>
                    <Badge status={ot.status} />
                  </div>
                ))}
              </div>
            )}
          </CardBody>
        </Card>

        {role === 'coordinator' && (
          <Card>
            <CardHeader><CardTitle>Status Penggajian</CardTitle></CardHeader>
            <CardBody className="p-0">
              <div className="divide-y divide-gray-50">
                {payrolls.map((p) => (
                  <div key={p.id} className="px-4 py-3 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{p.companyName}</p>
                      <p className="text-xs text-gray-400 mt-0.5">Periode {p.period_month}/{p.period_year}</p>
                    </div>
                    <Badge status={p.status} />
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        )}

        {role !== 'coordinator' && (
          <Card>
            <CardHeader><CardTitle>Aktivitas Terbaru</CardTitle></CardHeader>
            <CardBody>
              <div className="space-y-4">
                {[
                  { text: 'Pengajuan lembur baru masuk', time: '10 menit lalu' },
                  { text: 'Data karyawan diperbarui', time: '1 jam lalu' },
                  { text: 'Lembur bulan lalu disetujui HRD', time: 'Kemarin' },
                ].map((a, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand mt-1.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-700">{a.text}</p>
                      <p className="text-xs text-gray-400 mt-0.5">{a.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        )}
      </div>
    </div>
  )
}
