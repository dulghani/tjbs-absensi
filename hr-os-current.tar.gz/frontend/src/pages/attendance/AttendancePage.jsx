import { useEffect, useState } from 'react'
import { AlertTriangle } from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { getAttendanceSummariesPaginated, getAttendanceStats, getCompanies, getEmployeeDepartments } from '../../api/realService'
import { Card, CardBody, Select } from '../../components/ui/Primitives'
import Badge from '../../components/ui/Badge'
import { Table, Thead, Tbody, Tr, Th, Td, TableEmpty, Pagination, PageSizeSelector } from '../../components/ui/Table'
import { fDate, fDuration, cn } from '../../lib/utils'

function todayStr() { return new Date().toISOString().slice(0, 10) }
function daysAgoStr(n) { return new Date(Date.now() - n * 86400000).toISOString().slice(0, 10) }

export default function AttendancePage() {
  const user = useAuthStore((s) => s.user)
  const role = user?.roles?.[0]
  const isMultiCompany = ['coordinator', 'field_officer'].includes(role)

  const [records, setRecords] = useState(null)
  const [total, setTotal] = useState(0)
  const [stats, setStats] = useState(null)
  const [companies, setCompanies] = useState([])
  const [departments, setDepartments] = useState([])
  const [filterCompany, setFilterCompany] = useState(isMultiCompany ? 'all' : user.company_id)
  const [filterDepartment, setFilterDepartment] = useState('all')
  const [filterStatus, setFilterStatus] = useState('all')
  const [fromDate, setFromDate] = useState(daysAgoStr(6)) // default: 7 hari terakhir
  const [toDate, setToDate] = useState(todayStr())
  const [page, setPage] = useState(1)
  const [perPage, setPerPage] = useState(25)

  useEffect(() => { getCompanies().then(setCompanies) }, [])
  useEffect(() => { getEmployeeDepartments(filterCompany).then(setDepartments) }, [filterCompany])
  useEffect(() => { setPage(1) }, [filterCompany, filterDepartment, filterStatus, fromDate, toDate, perPage])
  useEffect(() => { load() }, [filterCompany, filterDepartment, filterStatus, fromDate, toDate, page, perPage])
  // Statistik dihitung terpisah dari tabel (agregat seluruh rentang, bukan cuma halaman aktif).
  useEffect(() => {
    getAttendanceStats({ company_id: filterCompany, department: filterDepartment, from_date: fromDate, to_date: toDate }).then(setStats)
  }, [filterCompany, filterDepartment, fromDate, toDate])

  async function load() {
    const result = await getAttendanceSummariesPaginated(
      { company_id: filterCompany, department: filterDepartment, status: filterStatus, from_date: fromDate, to_date: toDate },
      page, perPage
    )
    setRecords(result.data)
    setTotal(result.total)
  }

  const totalPages = Math.max(1, Math.ceil(total / perPage))

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Data Absensi</h2>
        <p className="text-sm text-gray-500 mt-0.5">Log kehadiran & hasil perhitungan jam kerja — {total} entri</p>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="p-4"><p className="text-xs text-gray-500 mb-1">Hadir</p><p className="text-xl font-semibold text-green-600">{stats.present}</p></Card>
          <Card className="p-4"><p className="text-xs text-gray-500 mb-1">Terlambat</p><p className="text-xl font-semibold text-amber-600">{stats.late}</p></Card>
          <Card className="p-4"><p className="text-xs text-gray-500 mb-1">Absen</p><p className="text-xl font-semibold text-red-600">{stats.absent}</p></Card>
          <Card className="p-4"><p className="text-xs text-gray-500 mb-1">Cuti</p><p className="text-xl font-semibold text-blue-600">{stats.on_leave}</p></Card>
        </div>
      )}

      <div className="flex flex-wrap items-end gap-2">
        <div>
          <label className="block text-[11px] font-medium text-gray-500 mb-1">Dari Tanggal</label>
          <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} max={toDate} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none" />
        </div>
        <div>
          <label className="block text-[11px] font-medium text-gray-500 mb-1">Sampai Tanggal</label>
          <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} min={fromDate} max={todayStr()} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none" />
        </div>
        {isMultiCompany && (
          <select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
            <option value="all">Semua Perusahaan</option>
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
        <select value={filterDepartment} onChange={(e) => setFilterDepartment(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
          <option value="all">Semua Departemen</option>
          {departments.map((d) => <option key={d} value={d}>{d}</option>)}
        </select>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
          <option value="all">Semua Status</option>
          <option value="present">Hadir</option>
          <option value="late">Terlambat</option>
          <option value="absent">Absen</option>
          <option value="on_leave">Cuti</option>
        </select>
        <div className="ml-auto"><PageSizeSelector value={perPage} onChange={setPerPage} /></div>
      </div>

      <Card>
        <CardBody className="p-0 sm:p-4">
          <Table>
            <Thead><Tr>
              <Th>Tanggal</Th><Th>Karyawan</Th><Th>Departemen</Th><Th>Jam Masuk</Th><Th>Jam Keluar</Th><Th>Jam Kerja</Th><Th>Lembur</Th><Th>Status</Th>
            </Tr></Thead>
            <Tbody>
              {!records ? null : records.length === 0 ? <TableEmpty colSpan={8} /> : records.map((r) => (
                <Tr key={r.id}>
                  <Td>{fDate(r.date)}</Td>
                  <Td className="font-medium text-gray-900">{r.employeeName}</Td>
                  <Td>{r.department}</Td>
                  <Td>{r.checkIn || '-'}</Td>
                  <Td>
                    {r.checkOut || '-'}
                    {r.checkIn && r.checkOut && r.checkOut < r.checkIn && (
                      <span className="ml-1 text-[10px] text-amber-600 font-medium" title="Check-out terjadi di hari berikutnya (shift lintas tengah malam)">+1 hari</span>
                    )}
                  </Td>
                  <Td>{fDuration(r.workMinutes)}</Td>
                  <Td>
                    {r.overtimeMinutes > 0 ? (
                      <span
                        className={cn(
                          'font-medium',
                          r.overtimeVerified === true && 'text-green-600',
                          r.overtimeVerified === false && 'text-amber-600',
                          r.overtimeVerified == null && 'text-gray-600'
                        )}
                        title={
                          r.overtimeVerified === true ? 'Sesuai dengan pengajuan lembur yang disetujui'
                          : r.overtimeVerified === false ? 'Lembur tercatat tapi TIDAK ada pengajuan lembur — cek manual'
                          : undefined
                        }
                      >
                        {fDuration(r.overtimeMinutes)}
                        {r.overtimeVerified === false && <AlertTriangle size={11} className="inline ml-1 mb-0.5" />}
                      </span>
                    ) : '-'}
                  </Td>
                  <Td><Badge status={r.status} /></Td>
                </Tr>
              ))}
            </Tbody>
          </Table>
          <Pagination page={page} totalPages={totalPages} onPageChange={setPage} total={total} perPage={perPage} />
        </CardBody>
      </Card>
    </div>
  )
}
