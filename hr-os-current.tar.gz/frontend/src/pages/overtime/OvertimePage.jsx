import { useEffect, useState } from 'react'
import { useForm, useFieldArray } from 'react-hook-form'
import { Plus, Trash2, Clock, Check, X, ChevronDown, ChevronUp, Building2, Calendar, User } from 'lucide-react'
import { useAuthStore } from '../../stores/authStore'
import { getOvertimeRequests, createOvertimeRequest, approveOvertimeItem, rejectOvertimeItem, approveAllOvertime, getEmployees, getCompanies } from '../../api/realService'
import { Card, CardBody, Input, Select, EmptyState } from '../../components/ui/Primitives'
import Button from '../../components/ui/Button'
import Badge from '../../components/ui/Badge'
import Modal from '../../components/ui/Modal'
import { Table, Thead, Tbody, Tr, Th, Td } from '../../components/ui/Table'
import { fDate, fDuration, generateOTNumber } from '../../lib/utils'
import { toast } from '../../components/ui/Toast'
import { Clock as ClockIcon } from 'lucide-react'

export default function OvertimePage() {
  const user = useAuthStore((s) => s.user)
  const company = useAuthStore((s) => s.company)
  const role = user?.roles?.[0]
  const isMultiCompany = ['coordinator', 'field_officer'].includes(role)
  const isHrd = role === 'hrd'
  const isDept = role === 'staff_dept'
  const canCreate = ['staff_dept', 'field_officer', 'coordinator'].includes(role)

  const [requests, setRequests] = useState(null)
  const [expanded, setExpanded] = useState(null)
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterCompany, setFilterCompany] = useState('all')
  const [companies, setCompanies] = useState([])
  const [modalOpen, setModalOpen] = useState(false)

  useEffect(() => { getCompanies().then(setCompanies) }, [])
  useEffect(() => { load() }, [filterStatus, filterCompany])

  async function load() {
    const cid = isMultiCompany ? filterCompany : user.company_id
    const data = await getOvertimeRequests({ company_id: cid, status: filterStatus })
    setRequests(data)
  }

  async function handleApproveItem(reqId, itemId) {
    await approveOvertimeItem(reqId, itemId, user.name)
    toast.success('Item lembur disetujui')
    load()
  }
  async function handleRejectItem(reqId, itemId) {
    await rejectOvertimeItem(reqId, itemId)
    toast.warning('Item lembur ditolak')
    load()
  }
  async function handleApproveAll(reqId) {
    await approveAllOvertime(reqId, user.name)
    toast.success('Semua item lembur disetujui')
    load()
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">{isHrd ? 'Konfirmasi Lembur' : isDept ? 'Pengajuan Lembur' : 'Data Lembur'}</h2>
          <p className="text-sm text-gray-500 mt-0.5">{requests?.length ?? '...'} pengajuan lembur</p>
        </div>
        {canCreate && <Button variant="primary" icon={Plus} onClick={() => setModalOpen(true)}>Buat Pengajuan Lembur</Button>}
      </div>

      <div className="flex flex-wrap gap-2">
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
          <option value="all">Semua Status</option>
          <option value="pending">Menunggu</option>
          <option value="approved">Disetujui</option>
          <option value="rejected">Ditolak</option>
        </select>
        {isMultiCompany && (
          <select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} className="px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white outline-none">
            <option value="all">Semua Perusahaan</option>
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        )}
      </div>

      <div className="space-y-3">
        {requests?.length === 0 && (
          <Card><EmptyState icon={ClockIcon} title="Belum ada pengajuan lembur" /></Card>
        )}
        {requests?.map((ot) => (
          <Card key={ot.id}>
            <div className="p-4 flex items-center justify-between gap-3 flex-wrap">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-sm font-semibold text-gray-900">{ot.no}</span>
                  <Badge status={ot.status} />
                </div>
                <div className="flex items-center gap-3 text-xs text-gray-500 mt-1.5 flex-wrap">
                  <span className="flex items-center gap-1"><Building2 size={12} />{companies.find(c => c.id === ot.company_id)?.name}</span>
                  <span className="flex items-center gap-1"><Calendar size={12} />{fDate(ot.date)}</span>
                  <span className="flex items-center gap-1"><User size={12} />{ot.requestedBy}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" onClick={() => setExpanded(expanded === ot.id ? null : ot.id)}>
                  {expanded === ot.id ? <ChevronUp size={14} /> : <ChevronDown size={14} />} Detail
                </Button>
                {isHrd && ot.status === 'pending' && (
                  <Button variant="primary" size="sm" icon={Check} onClick={() => handleApproveAll(ot.id)}>Setujui Semua</Button>
                )}
              </div>
            </div>

            {expanded === ot.id && (
              <div className="border-t border-gray-100 p-4">
                {ot.description && <p className="text-xs text-gray-500 mb-3 bg-gray-50 rounded-lg p-2.5">{ot.description}</p>}
                <Table>
                  <Thead><Tr>
                    <Th>Karyawan</Th><Th>Jam Mulai</Th><Th>Jam Selesai</Th><Th>Durasi</Th><Th>Catatan</Th><Th>Status</Th>
                    {isHrd && ot.status === 'pending' && <Th>Aksi</Th>}
                  </Tr></Thead>
                  <Tbody>
                    {ot.items.map((it) => (
                      <Tr key={it.id}>
                        <Td className="font-medium text-gray-900">{it.employee}</Td>
                        <Td>{it.start}</Td>
                        <Td>{it.end}</Td>
                        <Td>{fDuration(it.duration)}</Td>
                        <Td className="text-gray-400">{it.notes || '-'}</Td>
                        <Td><Badge status={it.status} /></Td>
                        {isHrd && ot.status === 'pending' && (
                          <Td>
                            {it.status === 'pending' && (
                              <div className="flex gap-1">
                                <button onClick={() => handleApproveItem(ot.id, it.id)} className="p-1.5 bg-green-50 text-green-600 rounded-md hover:bg-green-100"><Check size={13} /></button>
                                <button onClick={() => handleRejectItem(ot.id, it.id)} className="p-1.5 bg-red-50 text-red-600 rounded-md hover:bg-red-100"><X size={13} /></button>
                              </div>
                            )}
                          </Td>
                        )}
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              </div>
            )}
          </Card>
        ))}
      </div>

      <OvertimeCreateModal open={modalOpen} onClose={() => setModalOpen(false)} onCreated={load} user={user} company={company} isDept={isDept} />
    </div>
  )
}

// ── Multi-item Overtime Creation Modal ──────────────────────────────────────────
function OvertimeCreateModal({ open, onClose, onCreated, user, company, isDept }) {
  const [employees, setEmployees] = useState([])
  const [companies, setCompanies] = useState([])
  const { register, control, handleSubmit, watch, reset, formState: { isSubmitting } } = useForm({
    defaultValues: {
      company_id: company?.id || '',
      date: new Date().toISOString().slice(0, 10),
      department: user?.department || '',
      description: '',
      items: [{ employee_id: '', start: '17:00', end: '19:00', notes: '' }],
    },
  })
  const { fields, append, remove } = useFieldArray({ control, name: 'items' })
  const selectedCompanyId = watch('company_id')

  useEffect(() => { if (open) { getCompanies().then(setCompanies); reset({ company_id: company?.id || '', date: new Date().toISOString().slice(0, 10), department: user?.department || '', description: '', items: [{ employee_id: '', start: '17:00', end: '19:00', notes: '' }] }) } }, [open])
  useEffect(() => {
    if (selectedCompanyId) getEmployees({ company_id: selectedCompanyId }).then(setEmployees)
  }, [selectedCompanyId])

  function calcDuration(start, end) {
    if (!start || !end) return 0
    const [sh, sm] = start.split(':').map(Number)
    const [eh, em] = end.split(':').map(Number)
    let mins = (eh * 60 + em) - (sh * 60 + sm)
    if (mins < 0) mins += 24 * 60
    return mins
  }

  async function onSubmit(data) {
    try {
      const items = data.items.map((it) => {
        const emp = employees.find((e) => e.id === it.employee_id)
        return { ...it, employee: emp?.name || '', duration: calcDuration(it.start, it.end) }
      })
      await createOvertimeRequest({
        company_id: data.company_id, department: data.department, date: data.date,
        description: data.description, requestedBy: user.name, items,
      })
      toast.success('Pengajuan lembur berhasil dikirim')
      onClose(); onCreated()
    } catch { toast.error('Gagal membuat pengajuan') }
  }

  return (
    <Modal
      open={open} onClose={onClose} size="xl" title="Buat Pengajuan Lembur"
      subtitle="Tambahkan beberapa karyawan sekaligus dalam satu nomor lembur"
      footer={<>
        <Button variant="secondary" onClick={onClose}>Batal</Button>
        <Button variant="primary" loading={isSubmitting} onClick={handleSubmit(onSubmit)}>Submit Pengajuan</Button>
      </>}
    >
      <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
        <div className="grid grid-cols-2 gap-3">
          <Select label="Perusahaan" {...register('company_id', { required: true })} disabled={!!company}>
            {!company && <option value="">-- Pilih --</option>}
            {companies.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <Input label="Tanggal Lembur" type="date" {...register('date', { required: true })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Departemen" placeholder="Nama departemen" {...register('department', { required: true })} />
          <Input label="Keterangan" placeholder="Alasan lembur..." {...register('description')} />
        </div>

        <div className="border-t border-gray-100 pt-4">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold text-gray-800">Daftar Karyawan Lembur</p>
            <Button type="button" variant="primary" size="sm" icon={Plus} onClick={() => append({ employee_id: '', start: '17:00', end: '19:00', notes: '' })}>
              Tambah Karyawan
            </Button>
          </div>

          <div className="bg-gray-50 rounded-xl p-3 space-y-2.5">
            <div className="grid grid-cols-[2fr_1fr_1fr_2fr_32px] gap-2 px-1">
              {['Karyawan', 'Jam Mulai', 'Jam Selesai', 'Catatan', ''].map((h) => (
                <span key={h} className="text-[11px] font-medium text-gray-500">{h}</span>
              ))}
            </div>
            {fields.map((field, idx) => (
              <div key={field.id} className="grid grid-cols-[2fr_1fr_1fr_2fr_32px] gap-2 items-center">
                <select {...register(`items.${idx}.employee_id`, { required: true })} className="text-xs px-2.5 py-2 border border-gray-300 rounded-lg bg-white outline-none focus:border-brand">
                  <option value="">-- Pilih Karyawan --</option>
                  {employees.map((e) => <option key={e.id} value={e.id}>{e.name} ({e.department})</option>)}
                </select>
                <input type="time" {...register(`items.${idx}.start`, { required: true })} className="text-xs px-2 py-2 border border-gray-300 rounded-lg bg-white outline-none focus:border-brand" />
                <input type="time" {...register(`items.${idx}.end`, { required: true })} className="text-xs px-2 py-2 border border-gray-300 rounded-lg bg-white outline-none focus:border-brand" />
                <input placeholder="Opsional..." {...register(`items.${idx}.notes`)} className="text-xs px-2.5 py-2 border border-gray-300 rounded-lg bg-white outline-none focus:border-brand" />
                <button type="button" onClick={() => fields.length > 1 && remove(idx)} disabled={fields.length === 1} className="p-2 text-gray-300 hover:text-red-500 disabled:opacity-30 disabled:hover:text-gray-300">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-2 flex items-center gap-1"><ClockIcon size={12} /> {fields.length} karyawan dalam pengajuan ini</p>
        </div>
      </form>
    </Modal>
  )
}
