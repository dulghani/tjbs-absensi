// Real service layer — memanggil backend Laravel asli lewat axios (lihat api/index.js),
// lalu MENORMALISASI hasilnya supaya bentuknya identik dengan mockService.js.
// Tujuannya: halaman React yang sudah dibangun di atas mockService bisa langsung
// pindah ke backend asli cukup dengan ganti 1 baris import, tanpa ubah JSX apa pun.
import api from './index'

const unwrap = (res) => res.data // res sudah lolos axios interceptor (lihat api/index.js), res = body JSON
const unwrapPaginated = (res) => res.data.data // Laravel paginate(): {data: {data: [...], links, meta}}

// ── Auth ──────────────────────────────────────────────────────────────────────
export async function realLogin({ email, password }) {
  const res = await api.post('/auth/login', { email, password })
  // Backend: { user: {...., company: {...}|null}, token }
  const user = { ...res.user, roles: [res.user.role] } // mock pakai user.roles (array), backend pakai user.role (string)
  return { user, company: res.user.company || null, token: res.token }
}

// ── Companies ─────────────────────────────────────────────────────────────────
function normalizeCompany(c) {
  return { ...c, employees: c.employees_count ?? c.employees ?? 0 }
}
export async function getCompanies() {
  const res = await api.get('/organizations/companies')
  return unwrap(res).map(normalizeCompany)
}
export async function getCompany(id) {
  const res = await api.get(`/organizations/companies/${id}`)
  return normalizeCompany(unwrap(res))
}
export async function createCompany(data) {
  const res = await api.post('/organizations/companies', data)
  return normalizeCompany(unwrap(res))
}
export async function updateCompany(id, data) {
  const res = await api.patch(`/organizations/companies/${id}`, data)
  return normalizeCompany(unwrap(res))
}

// ── Org hierarchy ─────────────────────────────────────────────────────────────
export async function getOrgTree(companyId) {
  const res = await api.get(`/organizations/companies/${companyId}/tree`)
  return res // tree dikembalikan langsung tanpa wrapper 'data' oleh backend
}
export async function getDepartments(companyId) {
  const res = await api.get(`/organizations/companies/${companyId}/departments`)
  return unwrap(res)
}
export async function getDivisions(companyId) {
  const res = await api.get(`/organizations/companies/${companyId}/divisions`)
  return unwrap(res)
}
export async function createDepartment(companyId, data) {
  const res = await api.post(`/organizations/companies/${companyId}/departments`, data)
  return unwrap(res)
}
export async function createDivision(companyId, data) {
  const res = await api.post(`/organizations/companies/${companyId}/divisions`, data)
  return unwrap(res)
}

// ── Employees ─────────────────────────────────────────────────────────────────
function normalizeEmployee(e) {
  return {
    ...e,
    companyName: e.company?.name,
    joinDate: e.join_date,
    employmentStatus: e.employment_status,
    ktp: e.ktp_number,
  }
}
function denormalizeEmployeePayload(data) {
  const { employmentStatus, joinDate, ktp, ...rest } = data
  return {
    ...rest,
    ...(employmentStatus && { employment_status: employmentStatus }),
    ...(joinDate && { join_date: joinDate }),
    ...(ktp && { ktp_number: ktp }),
  }
}
export async function getEmployees(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  if (params.status === 'all') delete params.status
  const res = await api.get('/employees', { params })
  return unwrapPaginated(res).map(normalizeEmployee)
}
// Versi server-side pagination — dipakai EmployeesPage supaya bisa handle ratusan
// data tanpa perlu tarik semua sekaligus ke browser. Beda dari getEmployees() di atas
// (yang cuma balikin array 50 data pertama, tanpa info total/halaman lain).
export async function getEmployeesPaginated(filters = {}, page = 1, perPage = 25) {
  const params = { ...filters, page, per_page: perPage }
  if (params.company_id === 'all') delete params.company_id
  if (params.status === 'all') delete params.status
  const res = await api.get('/employees', { params })
  const paginator = res.data // {data: [...], current_page, last_page, total, ...}
  return {
    data: paginator.data.map(normalizeEmployee),
    total: paginator.total, currentPage: paginator.current_page, lastPage: paginator.last_page,
  }
}
export async function getEmployee(id) {
  const res = await api.get(`/employees/${id}`)
  return normalizeEmployee(unwrap(res))
}
export async function createEmployee(data) {
  const res = await api.post('/employees', denormalizeEmployeePayload(data))
  return normalizeEmployee(unwrap(res))
}
export async function updateEmployee(id, data) {
  const res = await api.patch(`/employees/${id}`, denormalizeEmployeePayload(data))
  return normalizeEmployee(unwrap(res))
}
export async function deleteEmployee(id) {
  const res = await api.delete(`/employees/${id}`)
  return unwrap(res)
}

// ── Shifts ────────────────────────────────────────────────────────────────────
export async function getShifts(companyId) {
  const res = await api.get(`/shifts/companies/${companyId}/shifts`)
  return unwrap(res)
}
export async function createShift(companyId, data) {
  const res = await api.post(`/shifts/companies/${companyId}/shifts`, data)
  return unwrap(res)
}
export async function updateShift(id, data) {
  const res = await api.patch(`/shifts/${id}`, data)
  return unwrap(res)
}
export async function deleteShift(id) {
  const res = await api.delete(`/shifts/${id}`)
  return unwrap(res)
}

// ── Work settings ─────────────────────────────────────────────────────────────
function normalizeWorkSettings(s, tiers = []) {
  if (!s) return null
  return {
    workStart: s.work_start_time, workEnd: s.work_end_time, breakMin: s.break_duration_minutes,
    workDays: s.work_days || [1, 1, 1, 1, 1, 0, 0],
    dailyHoursOverride: s.daily_hours_override || {},
    lateTolerance: s.late_tolerance_minutes, otMinMin: s.overtime_min_minutes,
    otMethod: s.overtime_calc_method,
    tiers: tiers.map((t) => ({ id: t.id, dayType: t.day_type, from: t.hour_from, to: t.hour_to, multiplier: t.multiplier })),
  }
}
export async function getWorkSettings(companyId) {
  const [settingRes, tiersRes] = await Promise.all([
    api.get(`/payroll/work-settings/${companyId}`),
    api.get(`/payroll/overtime-rates/${companyId}`),
  ])
  return normalizeWorkSettings(unwrap(settingRes), unwrap(tiersRes))
}
export async function createOvertimeRateTier(companyId, data) {
  const payload = { company_id: companyId, day_type: data.dayType, tier_order: data.tierOrder, hour_from: data.from, hour_to: data.to || null, multiplier: data.multiplier }
  const res = await api.post('/payroll/overtime-rates', payload)
  return unwrap(res)
}
export async function deleteOvertimeRateTier(id) {
  const res = await api.delete(`/payroll/overtime-rates/${id}`)
  return unwrap(res)
}
export async function updateWorkSettings(companyId, data) {
  const payload = {
    work_start_time: data.workStart, work_end_time: data.workEnd, break_duration_minutes: data.breakMin,
    work_days: data.workDays, late_tolerance_minutes: data.lateTolerance,
    overtime_min_minutes: data.otMinMin,
    daily_hours_override: data.daily_hours_override || {},
    ...(data.effective_date && { effective_date: data.effective_date }),
  }
  const res = await api.patch(`/payroll/work-settings/${companyId}`, payload)
  return normalizeWorkSettings(unwrap(res))
}

// ── Salary components ─────────────────────────────────────────────────────────
function normalizeSalaryComponent(s) {
  return { ...s, name: s.component_name, type: s.component_type, calc: s.calculation_type, value: s.base_value, taxable: s.is_taxable, order: s.sort_order }
}
export async function getSalaryComponents(companyId) {
  const res = await api.get(`/payroll/components/${companyId}`)
  return unwrap(res).map(normalizeSalaryComponent)
}
export async function createSalaryComponent(companyId, data) {
  const payload = { company_id: companyId, component_name: data.name, component_type: data.type, calculation_type: data.calc, base_value: data.value, is_taxable: data.taxable }
  const res = await api.post('/payroll/components', payload)
  return normalizeSalaryComponent(unwrap(res))
}
export async function deleteSalaryComponent(id) {
  const res = await api.delete(`/payroll/components/${id}`)
  return unwrap(res)
}

// ── Attendance ────────────────────────────────────────────────────────────────
function normalizeAttendance(r) {
  return {
    // Backend kirim attendance_date sebagai ISO datetime lengkap ("2026-07-14T00:00:00...Z"),
    // sementara <input type="date"> di form filter cuma "2026-07-14" — potong ke 10 karakter
    // pertama supaya perbandingan string di halaman Absensi cocok.
    ...r, date: r.attendance_date?.slice(0, 10), status: r.attendance_status,
    employeeName: r.employee?.name, department: r.employee?.department,
    checkIn: r.actual_start_time, checkOut: r.actual_end_time,
    lateMinutes: r.late_minutes, overtimeMinutes: r.overtime_minutes, workMinutes: r.productive_work_minutes,
    overtimeVerified: r.overtime_verified, // true=hijau(ada pengajuan lembur), false=kuning(tidak ada), null=di bawah ambang batas
  }
}
export async function getAttendanceSummaries(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  const res = await api.get('/attendance/summaries', { params })
  // Backend sekarang pakai paginate() (sebelumnya limit(200) polos) — data asli ada di res.data.data.
  return res.data.data.map(normalizeAttendance)
}
export async function getAttendanceSummariesPaginated(filters = {}, page = 1, perPage = 25) {
  const params = { ...filters, page, per_page: perPage }
  if (params.company_id === 'all') delete params.company_id
  if (params.department === 'all') delete params.department
  if (params.status === 'all') delete params.status
  const res = await api.get('/attendance/summaries', { params })
  const paginator = res.data
  return {
    data: paginator.data.map(normalizeAttendance),
    total: paginator.total, currentPage: paginator.current_page, lastPage: paginator.last_page,
  }
}
export async function getEmployeeDepartments(companyId) {
  const res = await api.get('/employees/departments', { params: companyId && companyId !== 'all' ? { company_id: companyId } : {} })
  return unwrap(res)
}
export async function getAttendanceAnalytics(employeeId, month, year) {
  const res = await api.get(`/attendance/analytics/${employeeId}/${month}/${year}`)
  return unwrap(res)
}
export async function getAttendanceStats(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  if (params.department === 'all') delete params.department
  const res = await api.get('/attendance/summary-stats', { params })
  return unwrap(res)
}

// ── Overtime ──────────────────────────────────────────────────────────────────
function normalizeOvertime(o) {
  return {
    ...o, no: o.request_number, date: o.overtime_date, requestedBy: o.requestedBy?.name,
    approvedBy: o.approved_by,
    items: (o.details || []).map((d) => ({
      id: d.id, employee_id: d.employee_id, employee: d.employee?.name,
      start: d.plan_start_time, end: d.plan_end_time, duration: d.plan_duration_minutes,
      status: d.status, notes: d.notes,
    })),
  }
}
export async function getOvertimeRequests(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  if (params.status === 'all') delete params.status
  const res = await api.get('/overtime', { params })
  return unwrap(res).map(normalizeOvertime)
}
export async function createOvertimeRequest(data) {
  const payload = {
    company_id: data.company_id, department: data.department, overtime_date: data.date,
    description: data.description,
    items: data.items.map((it) => ({ employee_id: it.employee_id, start: it.start, end: it.end, notes: it.notes })),
  }
  const res = await api.post('/overtime', payload)
  return normalizeOvertime(unwrap(res))
}
export async function approveOvertimeItem(requestId, itemId) {
  const res = await api.post(`/overtime/${requestId}/items/${itemId}/approve`)
  return normalizeOvertime(unwrap(res))
}
export async function rejectOvertimeItem(requestId, itemId) {
  const res = await api.post(`/overtime/${requestId}/items/${itemId}/reject`)
  return normalizeOvertime(unwrap(res))
}
export async function approveAllOvertime(requestId) {
  const res = await api.post(`/overtime/${requestId}/approve-all`)
  return normalizeOvertime(unwrap(res))
}

// ── Payroll ───────────────────────────────────────────────────────────────────
function normalizePayroll(p) {
  return { ...p, companyName: p.company?.name, employees: p.employee_count, totalGross: p.total_gross, totalNet: p.total_net }
}
export async function getPayrolls(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  const res = await api.get('/payroll', { params })
  return unwrap(res).map(normalizePayroll)
}
export async function processPayroll(data) {
  const res = await api.post('/payroll/process', data)
  return normalizePayroll(unwrap(res))
}
export async function finalizePayroll(id) {
  const res = await api.post(`/payroll/${id}/finalize`)
  return normalizePayroll(unwrap(res))
}

// ── Documents ─────────────────────────────────────────────────────────────────
function normalizeDocument(d) {
  return {
    ...d, number: d.document_number, category: d.category?.name, effectiveDate: d.effective_date,
    requiresAck: d.requires_acknowledgment, status: d.current_approval_status,
    ackCount: d.acknowledgments_count ?? 0, totalTarget: d.total_target ?? '?',
    createdAt: d.created_at,
  }
}
export async function getDocuments(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  const res = await api.get('/documents', { params })
  return unwrap(res).map(normalizeDocument)
}
// Cari/buat kategori dulu by nama (backend butuh category_id, form UI cuma punya nama kategori),
// baru kirim dokumennya. Sedikit tidak efisien (2 request) tapi menjaga DocumentsPage.jsx tetap sama.
export async function createDocument(data) {
  const catCode = data.category.toUpperCase().replace(/\s+/g, '_').slice(0, 40)
  const catRes = await api.post('/documents/categories', { company_id: data.company_id, code: catCode, name: data.category })
  const category = unwrap(catRes)

  const payload = {
    company_id: data.company_id, category_id: category.id, title: data.title,
    effective_date: data.effectiveDate, requires_acknowledgment: data.requiresAck,
  }
  const res = await api.post('/documents', payload)
  return normalizeDocument({ ...unwrap(res), category })
}

// ── Notifications ─────────────────────────────────────────────────────────────
function normalizeNotification(n) {
  return { ...n, type: n.related_entity_type, entityId: n.related_entity_id, read: !!n.read_at, createdAt: n.created_at }
}
export async function getNotifications() {
  const res = await api.get('/notifications/me')
  return unwrap(res).map(normalizeNotification)
}
export async function markNotificationRead(id) {
  const res = await api.post(`/notifications/${id}/mark-read`)
  return unwrap(res)
}
export async function markAllNotificationsRead() {
  const res = await api.post('/notifications/mark-all-read')
  return unwrap(res)
}

// ── Users ─────────────────────────────────────────────────────────────────────
function normalizeUser(u) {
  return { ...u, roles: [u.role], companyName: u.company?.name }
}
export async function getUsers(filters = {}) {
  const params = { ...filters }
  if (params.company_id === 'all') delete params.company_id
  const res = await api.get('/users', { params })
  return unwrap(res).map(normalizeUser)
}
export async function createUser(data) {
  const payload = { name: data.name, email: data.email, phone: data.phone, role: data.roles[0], company_id: data.company_id || null, department: data.department || null }
  const res = await api.post('/users', payload)
  return normalizeUser(unwrap(res))
}
export async function updateUser(id, data) {
  const res = await api.patch(`/users/${id}`, data)
  return normalizeUser(unwrap(res))
}
export async function deleteUser(id) {
  const res = await api.delete(`/users/${id}`)
  return unwrap(res)
}

// ── Role Permissions ──────────────────────────────────────────────────────────
// CATATAN: backend belum punya tabel/endpoint role_permissions granular (baru pakai
// kolom 'role' sederhana di users). Fitur toggle permission di UI ini untuk saat ini
// masih disimpan di memori browser saja (tidak persisten ke server). Lihat README
// backend bagian "Catatan Implementasi Lanjutan" untuk rencana migrasi ke
// spatie/laravel-permission.
import { ROLE_PERMISSIONS as DEFAULT_ROLE_PERMISSIONS } from './mockData'
const _localRolePermissions = { ...DEFAULT_ROLE_PERMISSIONS }

export async function getRolePermissions(role) {
  return _localRolePermissions[role] || []
}
export async function updateRolePermissions(role, permissions) {
  _localRolePermissions[role] = permissions
  return permissions
}

// ── Audit Logs ────────────────────────────────────────────────────────────────
function normalizeAuditLog(l) {
  return {
    ...l, user: l.user?.name, role: l.user?.role, action: l.action_category, entity: l.entity_type,
    entityName: l.entity_name, summary: l.changes_summary, timestamp: l.created_at, ip: l.source_ip,
  }
}
export async function getAuditLogs(filters = {}) {
  const params = {}
  if (filters.entity && filters.entity !== 'all') params.entity_type = filters.entity
  const res = await api.get('/audit-logs', { params })
  return unwrapPaginated(res).map(normalizeAuditLog)
}
export async function getAuditLogsPaginated(filters = {}, page = 1, perPage = 25) {
  const params = { page, per_page: perPage }
  if (filters.entity && filters.entity !== 'all') params.entity_type = filters.entity
  const res = await api.get('/audit-logs', { params })
  const paginator = res.data
  return {
    data: paginator.data.map(normalizeAuditLog),
    total: paginator.total, currentPage: paginator.current_page, lastPage: paginator.last_page,
  }
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
export async function getDashboardStats() {
  const res = await api.get('/dashboard/stats')
  return unwrap(res)
}

// ── Attendance Devices (Fingerspot) — struktur sudah 1:1 cocok dengan backend ──
export async function getDevices(companyId) {
  const res = await api.get('/attendance-devices', { params: companyId && companyId !== 'all' ? { company_id: companyId } : {} })
  return unwrap(res).map((d) => ({ ...d, companyName: d.company?.name, lineName: d.line?.name }))
}
export async function createDevice(data) {
  const res = await api.post('/attendance-devices', data)
  return unwrap(res)
}
export async function updateDevice(id, data) {
  const res = await api.patch(`/attendance-devices/${id}`, data)
  return unwrap(res)
}
export async function deleteDevice(id) {
  const res = await api.delete(`/attendance-devices/${id}`)
  return unwrap(res)
}
export async function testDeviceConnection(id) {
  try {
    const res = await api.post(`/attendance-devices/${id}/test-connection`)
    return unwrap(res)
  } catch (err) {
    return err // controller balikin 422 dgn {success:false,message} saat gagal, axios interceptor sudah unwrap err.response?.data
  }
}
export async function syncDeviceNow(id, dateOrRange = {}) {
  // dateOrRange bisa: {} (hari ini), {date: 'Y-m-d'} (1 tanggal), atau {from, to} (range/backdate)
  const res = await api.post(`/attendance-devices/${id}/sync-now`, dateOrRange)
  return unwrap(res)
}
export async function getSyncCoverage(deviceId, from, to) {
  const res = await api.get(`/attendance-devices/${deviceId}/sync-coverage`, { params: { from, to } })
  return unwrap(res)
}
export async function getSyncLogs(deviceId) {
  const res = await api.get(`/attendance-devices/${deviceId}/sync-logs`)
  return unwrap(res)
}
export async function getDeviceMappings(deviceId) {
  const res = await api.get(`/attendance-devices/${deviceId}/mappings`)
  return unwrap(res).map((m) => ({ ...m, employeeName: m.employee?.name, employeeNik: m.employee?.nik }))
}
export async function addDeviceMapping(deviceId, data) {
  const res = await api.post(`/attendance-devices/${deviceId}/mappings`, data)
  return unwrap(res)
}
export async function removeDeviceMapping(deviceId, mappingId) {
  // NOTE: signature mock lama removeDeviceMapping(id) cuma 1 arg; backend butuh deviceId juga.
  // DeviceIntegrationPage.jsx manggilnya removeDeviceMapping(m.id) — perlu sedikit penyesuaian
  // di halaman tsb kalau connect ke backend asli (lihat catatan di response chat).
  const res = await api.delete(`/attendance-devices/${deviceId}/mappings/${mappingId}`)
  return unwrap(res)
}

export async function importEmployeesToDevice(deviceId, file) {
  const formData = new FormData()
  formData.append('file', file)
  const res = await api.post(`/attendance-devices/${deviceId}/import-employees`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return unwrap(res)
}
