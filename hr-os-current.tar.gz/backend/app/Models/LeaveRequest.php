<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class LeaveRequest extends Model
{
    use HasUuids;

    protected $fillable = [
        'employee_id', 'company_id', 'leave_type_id', 'start_date', 'end_date', 'reason',
        'attachments', 'status', 'approved_by', 'approved_at', 'is_paid', 'deduction_type',
    ];
    protected $casts = ['start_date' => 'date:Y-m-d', 'end_date' => 'date:Y-m-d', 'approved_at' => 'datetime', 'attachments' => 'array', 'is_paid' => 'boolean'];

    public function employee() { return $this->belongsTo(Employee::class); }
    public function leaveType() { return $this->belongsTo(LeaveType::class); }
}
