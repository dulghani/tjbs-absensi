<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\CalculatePayrollJob;
use App\Models\AuditLog;
use App\Models\Company;
use App\Models\CompanyOvertimeRate;
use App\Models\CompanySalaryComponent;
use App\Models\CompanyWorkSetting;
use App\Models\Payroll;
use Illuminate\Http\Request;

class PayrollController extends Controller
{
    public function index(Request $request)
    {
        $query = Payroll::with('company:id,name');
        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);
        return response()->json(['data' => $query->latest('period_year')->latest('period_month')->get()]);
    }

    public function show(string $id)
    {
        return response()->json(['data' => Payroll::with(['company', 'details.employee'])->findOrFail($id)]);
    }

    /**
     * Proses payroll baru. Perhitungan detail (per komponen gaji, lembur, dst)
     * idealnya dijalankan sebagai queued Job terpisah (PayrollCalculationJob)
     * yang menarik data dari attendance_summaries + company_work_settings +
     * company_salary_components. Di sini disediakan kerangka awalnya.
     */
    public function process(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|uuid|exists:companies,id',
            'period_month' => 'required|integer|min:1|max:12',
            'period_year' => 'required|integer|min:2020',
            'effective_work_days' => 'nullable|integer|min:1|max:31',
        ]);

        $company = Company::withCount('employees')->findOrFail($data['company_id']);

        $payroll = Payroll::updateOrCreate(
            ['company_id' => $data['company_id'], 'period_month' => $data['period_month'], 'period_year' => $data['period_year']],
            [
                'status' => 'processing',
                'effective_work_days' => $data['effective_work_days'] ?? null,
                'generated_by' => $request->user()->id,
                'generated_at' => now(),
                'employee_count' => $company->employees_count,
            ]
        );

        // Hitung gross/net per karyawan secara async (bisa banyak karyawan, jangan blocking request).
        CalculatePayrollJob::dispatch($payroll->id);

        AuditLog::record(['company_id' => $payroll->company_id, 'action_category' => 'create', 'entity_type' => 'payroll', 'entity_id' => $payroll->id, 'entity_name' => "Payroll {$company->name} {$data['period_month']}/{$data['period_year']}"]);

        return response()->json(['data' => $payroll], 201);
    }

    public function finalize(string $id)
    {
        $payroll = Payroll::findOrFail($id);
        $payroll->update(['status' => 'finalized', 'finalized_at' => now()]);

        AuditLog::record(['company_id' => $payroll->company_id, 'action_category' => 'approve', 'entity_type' => 'payroll', 'entity_id' => $payroll->id, 'entity_name' => "Payroll {$payroll->period_month}/{$payroll->period_year}", 'changes_summary' => 'Payroll difinalisasi']);

        return response()->json(['data' => $payroll]);
    }

    // ── Work Settings (Aturan Kerja per Perusahaan) ──────────────────────────────
    public function getWorkSettings(string $companyId)
    {
        $setting = CompanyWorkSetting::where('company_id', $companyId)->latest('effective_date')->first();
        return response()->json(['data' => $setting]);
    }

    public function updateWorkSettings(Request $request, string $companyId)
    {
        $data = $request->validate([
            'work_start_time' => 'required',
            'work_end_time' => 'required',
            'break_duration_minutes' => 'nullable|integer',
            'work_days' => 'nullable|array',
            'daily_hours_override' => 'nullable|array',
            'overtime_min_minutes' => 'nullable|integer',
            'late_tolerance_minutes' => 'nullable|integer',
            'effective_date' => 'nullable|date',
        ]);

        // Versioning: setting lama TIDAK di-overwrite, insert record baru dengan
        // effective_date baru supaya payroll periode lalu tetap pakai aturan lama.
        $setting = CompanyWorkSetting::create($data + [
            'company_id' => $companyId,
            'effective_date' => $data['effective_date'] ?? now()->addMonth()->startOfMonth()->format('Y-m-d'),
            'created_by' => $request->user()->id,
        ]);

        return response()->json(['data' => $setting], 201);
    }

    // ── Salary Components ────────────────────────────────────────────────────────
    public function salaryComponents(string $companyId)
    {
        return response()->json(['data' => CompanySalaryComponent::where('company_id', $companyId)->orderBy('sort_order')->get()]);
    }

    public function storeSalaryComponent(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|uuid|exists:companies,id',
            'component_name' => 'required|string|max:255',
            'component_type' => 'required|in:earning,deduction',
            'calculation_type' => 'required|in:fixed,percentage,formula,manual,per_hari,daily_wage_rate,overtime_holiday,attendance_earning,overtime_regular,absence_deduction,early_leave_deduction',
            'base_value' => 'nullable|numeric',
            'formula' => 'nullable|string',
            'is_taxable' => 'nullable|boolean',
        ]);

        $component = CompanySalaryComponent::create($data);
        return response()->json(['data' => $component], 201);
    }

    public function deleteSalaryComponent(string $id)
    {
        CompanySalaryComponent::findOrFail($id)->delete();
        return response()->json(['success' => true]);
    }

    // ── Overtime Rate Tiers ───────────────────────────────────────────────────────
    public function overtimeRates(string $companyId)
    {
        return response()->json(['data' => CompanyOvertimeRate::where('company_id', $companyId)->orderBy('day_type')->orderBy('tier_order')->get()]);
    }

    public function storeOvertimeRate(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|uuid|exists:companies,id',
            'day_type' => 'required|in:weekday,weekend,holiday',
            'tier_order' => 'required|integer|min:1',
            'hour_from' => 'required|integer|min:1',
            'hour_to' => 'nullable|integer|min:1',
            'multiplier' => 'nullable|numeric|min:0',
            'fixed_amount' => 'nullable|numeric|min:0',
        ]);

        $rate = CompanyOvertimeRate::create($data);
        return response()->json(['data' => $rate], 201);
    }

    public function deleteOvertimeRate(string $id)
    {
        CompanyOvertimeRate::findOrFail($id)->delete();
        return response()->json(['success' => true]);
    }
}
