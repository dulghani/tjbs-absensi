<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Employee;
use App\Models\OvertimeRequest;
use App\Models\Payroll;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function stats(Request $request)
    {
        $user = $request->user();
        $isMultiCompany = in_array($user->role, ['coordinator', 'field_officer'], true);
        $companyScope = $isMultiCompany ? null : $user->company_id;

        $employeeQuery = Employee::where('status', 'active');
        if ($companyScope) $employeeQuery->where('company_id', $companyScope);

        $otQuery = OvertimeRequest::query();
        if ($companyScope) $otQuery->where('company_id', $companyScope);

        return response()->json(['data' => [
            'totalCompanies' => Company::count(),
            'totalEmployees' => $employeeQuery->count(),
            'pendingOvertime' => (clone $otQuery)->where('status', 'pending')->count(),
            'totalOvertimeThisMonth' => (clone $otQuery)->whereMonth('overtime_date', now()->month)->count(),
            'payrollDraft' => Payroll::where('status', 'draft')->count(),
            'payrollProcessing' => Payroll::where('status', 'processing')->count(),
            'payrollFinalized' => Payroll::where('status', 'finalized')->count(),
        ]]);
    }
}
