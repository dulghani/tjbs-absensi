<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index(Request $request)
    {
        $query = Employee::with('company:id,name');

        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);
        if ($request->department) $query->where('department', $request->department);
        if ($request->status && $request->status !== 'all') $query->where('status', $request->status);
        if ($request->search) {
            $s = $request->search;
            $query->where(fn ($q) => $q->whereLike('name', "%{$s}%")->orWhereLike('nik', "%{$s}%"));
        }

        return response()->json(['data' => $query->orderBy('name')->paginate($request->per_page ?? 50)]);
    }

    public function show(string $id)
    {
        return response()->json(['data' => Employee::with(['company', 'currentAssignment'])->findOrFail($id)]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|uuid|exists:companies,id',
            'nik' => 'nullable|string|max:30',
            'name' => 'required|string|max:255',
            'gender' => 'nullable|in:L,P',
            'department' => 'required|string|max:255',
            'line' => 'nullable|string|max:255',
            'position' => 'required|string|max:255',
            'employment_status' => 'nullable|in:probation,permanent,contract,temporary',
            'join_date' => 'required|date',
            'phone' => 'nullable|string|max:30',
            'address' => 'nullable|string',
            'ktp_number' => 'nullable|string|max:20',
        ]);

        $employee = Employee::create($data + ['status' => 'active']);
        AuditLog::record(['company_id' => $employee->company_id, 'action_category' => 'create', 'entity_type' => 'employee', 'entity_id' => $employee->id, 'entity_name' => $employee->name, 'changes_summary' => 'Menambahkan karyawan baru']);

        return response()->json(['data' => $employee], 201);
    }

    public function update(Request $request, string $id)
    {
        $employee = Employee::findOrFail($id);
        $old = $employee->only(array_keys($request->all()));

        $data = $request->validate([
            'nik' => 'nullable|string|max:30',
            'name' => 'sometimes|string|max:255',
            'gender' => 'nullable|in:L,P',
            'department' => 'sometimes|string|max:255',
            'line' => 'nullable|string|max:255',
            'position' => 'sometimes|string|max:255',
            'employment_status' => 'nullable|in:probation,permanent,contract,temporary',
            'phone' => 'nullable|string|max:30',
            'address' => 'nullable|string',
            'status' => 'nullable|in:active,inactive',
        ]);

        $employee->update($data);
        AuditLog::record(['company_id' => $employee->company_id, 'action_category' => 'update', 'entity_type' => 'employee', 'entity_id' => $employee->id, 'entity_name' => $employee->name, 'old_values' => $old, 'new_values' => $data]);

        return response()->json(['data' => $employee]);
    }

    public function destroy(string $id)
    {
        $employee = Employee::findOrFail($id);
        AuditLog::record(['company_id' => $employee->company_id, 'action_category' => 'delete', 'entity_type' => 'employee', 'entity_id' => $employee->id, 'entity_name' => $employee->name]);
        $employee->delete();

        return response()->json(['success' => true]);
    }

    /** Daftar departemen unik, dipakai buat dropdown filter di halaman lain (Absensi, dll). */
    public function departments(Request $request)
    {
        $query = Employee::query();
        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);

        $departments = $query->whereNotNull('department')->where('department', '!=', '')
            ->distinct()->orderBy('department')->pluck('department');

        return response()->json(['data' => $departments]);
    }
}
