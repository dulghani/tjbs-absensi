<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\Employee;
use App\Models\OvertimeRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OvertimeController extends Controller
{
    public function index(Request $request)
    {
        $query = OvertimeRequest::with(['details.employee:id,name', 'requestedBy:id,name']);

        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);
        if ($request->status && $request->status !== 'all') $query->where('status', $request->status);

        return response()->json(['data' => $query->latest('overtime_date')->get()]);
    }

    public function show(string $id)
    {
        return response()->json(['data' => OvertimeRequest::with(['details.employee', 'requestedBy:id,name'])->findOrFail($id)]);
    }

    /**
     * Buat pengajuan lembur dengan banyak item karyawan sekaligus (fitur "multiple add").
     * Payload: { company_id, department, overtime_date, description, items: [{employee_id, start, end, notes}] }
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'company_id' => 'required|uuid|exists:companies,id',
            'department' => 'required|string|max:255',
            'overtime_date' => 'required|date',
            'description' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.employee_id' => 'required|uuid|exists:employees,id',
            'items.*.start' => 'required',
            'items.*.end' => 'required',
            'items.*.notes' => 'nullable|string',
        ]);

        $overtimeRequest = DB::transaction(function () use ($data, $request) {
            $company = \App\Models\Company::findOrFail($data['company_id']);
            $requestNumber = $this->generateRequestNumber($company->code, $data['overtime_date']);

            $header = \App\Models\OvertimeRequest::create([
                'request_number' => $requestNumber,
                'company_id' => $data['company_id'],
                'department' => $data['department'],
                'requested_by' => $request->user()->id,
                'overtime_date' => $data['overtime_date'],
                'description' => $data['description'] ?? null,
                'status' => 'pending',
            ]);

            foreach ($data['items'] as $item) {
                $duration = $this->calcDurationMinutes($item['start'], $item['end']);
                $header->details()->create([
                    'employee_id' => $item['employee_id'],
                    'plan_start_time' => $item['start'],
                    'plan_end_time' => $item['end'],
                    'plan_duration_minutes' => $duration,
                    'notes' => $item['notes'] ?? null,
                    'status' => 'pending',
                ]);
            }

            return $header;
        });

        AuditLog::record([
            'company_id' => $overtimeRequest->company_id,
            'action_category' => 'create', 'entity_type' => 'overtime_request', 'entity_id' => $overtimeRequest->id,
            'entity_name' => $overtimeRequest->request_number,
            'changes_summary' => count($data['items']) . ' karyawan diajukan lembur',
        ]);

        return response()->json(['data' => $overtimeRequest->load('details.employee')], 201);
    }

    /** Approve satu item (karyawan) dalam sebuah pengajuan lembur. */
    public function approveItem(Request $request, string $requestId, string $itemId)
    {
        $header = OvertimeRequest::findOrFail($requestId);
        $item = $header->details()->findOrFail($itemId);
        $item->update(['status' => 'approved']);

        $this->finalizeIfComplete($header, $request->user()->id);

        return response()->json(['data' => $header->fresh('details.employee')]);
    }

    public function rejectItem(Request $request, string $requestId, string $itemId)
    {
        $header = OvertimeRequest::findOrFail($requestId);
        $item = $header->details()->findOrFail($itemId);
        $item->update(['status' => 'rejected']);

        $this->finalizeIfComplete($header, $request->user()->id);

        return response()->json(['data' => $header->fresh('details.employee')]);
    }

    public function approveAll(Request $request, string $requestId)
    {
        $header = OvertimeRequest::findOrFail($requestId);
        $header->details()->update(['status' => 'approved']);
        $header->update(['status' => 'approved', 'approved_by' => $request->user()->id, 'approved_at' => now()]);

        AuditLog::record(['company_id' => $header->company_id, 'action_category' => 'approve', 'entity_type' => 'overtime_request', 'entity_id' => $header->id, 'entity_name' => $header->request_number, 'changes_summary' => 'Menyetujui semua item lembur']);

        return response()->json(['data' => $header->fresh('details.employee')]);
    }

    protected function finalizeIfComplete(OvertimeRequest $header, string $approverId): void
    {
        $items = $header->details;
        if ($items->contains('status', 'pending')) return; // masih ada yang belum diputuskan

        $header->update([
            'status' => $items->contains('status', 'approved') ? 'approved' : 'rejected',
            'approved_by' => $approverId,
            'approved_at' => now(),
        ]);
    }

    protected function calcDurationMinutes(string $start, string $end): int
    {
        [$sh, $sm] = array_map('intval', explode(':', $start));
        [$eh, $em] = array_map('intval', explode(':', $end));
        $minutes = ($eh * 60 + $em) - ($sh * 60 + $sm);
        return $minutes < 0 ? $minutes + 1440 : $minutes; // lintas tengah malam
    }

    protected function generateRequestNumber(string $companyCode, string $date): string
    {
        $ym = date('Ym', strtotime($date));
        $prefix = "OT-{$companyCode}-{$ym}-";
        $count = OvertimeRequest::where('request_number', 'like', "{$prefix}%")->count();
        return $prefix . str_pad($count + 1, 3, '0', STR_PAD_LEFT);
    }
}
