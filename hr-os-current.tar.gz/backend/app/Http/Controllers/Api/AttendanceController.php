<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AttendanceLog;
use App\Models\AttendanceSummary;
use App\Models\Employee;
use App\Models\LeaveRequest;
use App\Models\LeaveType;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function checkIn(Request $request)
    {
        $data = $request->validate([
            'employee_id' => 'required|uuid|exists:employees,id',
            'line_id' => 'nullable|uuid',
            'biometric_type' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $employee = Employee::findOrFail($data['employee_id']);

        $log = AttendanceLog::create($data + [
            'company_id' => $employee->company_id,
            'log_type' => 'check_in',
            'logged_time' => now(),
            'verification_status' => 'auto',
        ]);

        return response()->json(['status' => 'success', 'message' => 'Check-in recorded', 'data' => $log]);
    }

    public function checkOut(Request $request)
    {
        $data = $request->validate([
            'employee_id' => 'required|uuid|exists:employees,id',
            'line_id' => 'nullable|uuid',
        ]);

        $employee = Employee::findOrFail($data['employee_id']);

        $log = AttendanceLog::create($data + [
            'company_id' => $employee->company_id,
            'log_type' => 'check_out',
            'logged_time' => now(),
            'verification_status' => 'auto',
        ]);

        return response()->json(['status' => 'success', 'message' => 'Check-out recorded', 'data' => $log]);
    }

    public function summaries(Request $request)
    {
        $query = AttendanceSummary::with('employee:id,name,department');

        if ($request->employee_id) $query->where('employee_id', $request->employee_id);
        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);
        if ($request->from_date) $query->where('attendance_date', '>=', $request->from_date);
        if ($request->to_date) $query->where('attendance_date', '<=', $request->to_date);
        if ($request->status && $request->status !== 'all') $query->where('attendance_status', $request->status);
        if ($request->department && $request->department !== 'all') {
            $query->whereHas('employee', fn ($q) => $q->where('department', $request->department));
        }

        return response()->json(['data' => $query->orderByDesc('attendance_date')->paginate($request->per_page ?? 200)]);
    }

    /**
     * Statistik Hadir/Terlambat/Absen/Cuti untuk SELURUH data yang cocok filter (bukan cuma
     * halaman yang sedang tampil) — dipakai kartu ringkasan di atas tabel Absensi supaya
     * angkanya tetap akurat meski tabelnya dipaginasi.
     */
    public function summaryStats(Request $request)
    {
        $query = AttendanceSummary::query();

        if ($request->company_id && $request->company_id !== 'all') $query->where('company_id', $request->company_id);
        if ($request->from_date) $query->where('attendance_date', '>=', $request->from_date);
        if ($request->to_date) $query->where('attendance_date', '<=', $request->to_date);
        if ($request->department && $request->department !== 'all') {
            $query->whereHas('employee', fn ($q) => $q->where('department', $request->department));
        }

        $counts = (clone $query)->selectRaw('attendance_status, count(*) as jumlah')->groupBy('attendance_status')->pluck('jumlah', 'attendance_status');

        return response()->json(['data' => [
            'present' => $counts->get('present', 0) + $counts->get('late', 0) + $counts->get('early_leave', 0),
            'late' => $counts->get('late', 0),
            'absent' => $counts->get('absent', 0),
            'on_leave' => $counts->get('on_leave', 0),
        ]]);
    }

    public function daily(string $employeeId, string $date)
    {
        $summary = AttendanceSummary::with('employee')
            ->where('employee_id', $employeeId)
            ->where('attendance_date', $date)
            ->first();

        return response()->json(['data' => $summary]);
    }

    public function analytics(string $employeeId, int $month, int $year)
    {
        $summaries = AttendanceSummary::where('employee_id', $employeeId)
            ->whereMonth('attendance_date', $month)
            ->whereYear('attendance_date', $year)
            ->get();

        return response()->json(['data' => [
            'total_days_in_period' => $summaries->count(),
            'days_present' => $summaries->whereIn('attendance_status', ['present', 'late'])->count(),
            'days_absent' => $summaries->where('attendance_status', 'absent')->count(),
            'days_late' => $summaries->where('attendance_status', 'late')->count(),
            'days_on_leave' => $summaries->where('attendance_status', 'on_leave')->count(),
            'total_work_hours' => round($summaries->sum('productive_work_minutes') / 60, 2),
            'total_overtime_hours' => round($summaries->sum('overtime_minutes') / 60, 2),
            'attendance_percentage' => $summaries->count() ? round($summaries->whereIn('attendance_status', ['present', 'late'])->count() / $summaries->count() * 100, 1) : 0,
        ]]);
    }

    // ── Leave ─────────────────────────────────────────────────────────────────
    public function leaveTypes(string $companyId)
    {
        return response()->json(['data' => LeaveType::where('company_id', $companyId)->where('status', 'active')->get()]);
    }

    public function storeLeaveRequest(Request $request)
    {
        $data = $request->validate([
            'employee_id' => 'required|uuid|exists:employees,id',
            'leave_type_id' => 'nullable|uuid|exists:leave_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'reason' => 'nullable|string',
        ]);

        $employee = Employee::findOrFail($data['employee_id']);
        $leave = LeaveRequest::create($data + ['company_id' => $employee->company_id, 'status' => 'submitted']);

        return response()->json(['data' => $leave], 201);
    }

    public function approveLeaveRequest(Request $request, string $id)
    {
        $leave = LeaveRequest::findOrFail($id);
        $leave->update(['status' => 'approved', 'approved_by' => $request->user()->id, 'approved_at' => now()]);

        // Tandai setiap hari dalam rentang cuti sebagai 'on_leave' di attendance_summaries.
        $cursor = \Carbon\Carbon::parse($leave->start_date);
        $end = \Carbon\Carbon::parse($leave->end_date);
        while ($cursor->lte($end)) {
            AttendanceSummary::updateOrCreate(
                ['employee_id' => $leave->employee_id, 'attendance_date' => $cursor->format('Y-m-d')],
                ['company_id' => $leave->company_id, 'attendance_status' => 'on_leave', 'expected_work_minutes' => 0, 'status' => 'auto_finalized']
            );
            $cursor->addDay();
        }

        return response()->json(['data' => $leave]);
    }
}
