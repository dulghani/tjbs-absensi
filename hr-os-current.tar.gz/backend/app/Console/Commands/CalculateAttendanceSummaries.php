<?php

namespace App\Console\Commands;

use App\Jobs\CalculateAttendanceSummaryJob;
use App\Models\AttendanceLog;
use App\Models\Employee;
use Illuminate\Console\Command;

class CalculateAttendanceSummaries extends Command
{
    protected $signature = 'attendance:calculate-summaries
                            {--date= : Tanggal yang dihitung, format Y-m-d (default: hari ini)}
                            {--employee= : Hitung hanya 1 karyawan tertentu (ID)}
                            {--all-active : Hitung SEMUA karyawan aktif, bukan cuma yang punya log hari itu (untuk tandai absent)}';

    protected $description = 'Hitung attendance_summaries dari attendance_logs (raw) untuk tanggal tertentu';

    public function handle(): int
    {
        $date = $this->option('date') ?? now()->format('Y-m-d');

        if ($this->option('employee')) {
            $employeeIds = collect([$this->option('employee')]);
        } elseif ($this->option('all-active')) {
            // Proses semua karyawan aktif — penting supaya yang TIDAK ada log sama sekali
            // tetap tercatat sebagai 'absent', bukan hilang begitu saja dari laporan.
            $employeeIds = Employee::where('status', 'active')->pluck('id');
        } else {
            // Default: hanya karyawan yang punya minimal 1 log hari itu (lebih ringan).
            $employeeIds = AttendanceLog::whereDate('logged_time', $date)->distinct()->pluck('employee_id');
        }

        if ($employeeIds->isEmpty()) {
            $this->warn("Tidak ada karyawan untuk diproses pada tanggal {$date}.");
            return self::SUCCESS;
        }

        $bar = $this->output->createProgressBar($employeeIds->count());
        $bar->start();

        foreach ($employeeIds as $employeeId) {
            CalculateAttendanceSummaryJob::dispatch($employeeId, $date);
            $bar->advance();
        }

        $bar->finish();
        $this->newLine(2);
        $this->info("{$employeeIds->count()} karyawan dijadwalkan ke queue untuk dihitung ({$date}).");

        return self::SUCCESS;
    }
}
