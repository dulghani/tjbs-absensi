<?php

namespace App\Console\Commands;

use App\Jobs\SyncFingerspotAttendanceJob;
use App\Models\AttendanceDevice;
use Carbon\Carbon;
use Illuminate\Console\Command;

class SyncAttendanceDevices extends Command
{
    protected $signature = 'attendance:sync-devices
                            {--date= : Tanggal tunggal yang disync, format Y-m-d (default: hari ini)}
                            {--from= : Tanggal awal untuk sync RANGE, format Y-m-d}
                            {--to= : Tanggal akhir untuk sync RANGE, format Y-m-d (wajib kalau --from diisi)}
                            {--device= : Sync hanya 1 device tertentu (ID)}';

    protected $description = 'Sinkronisasi log absensi dari mesin fingerprint aktif — 1 tanggal atau rentang tanggal (backdate aman, otomatis skip data yang sudah ada)';

    public function handle(): int
    {
        $deviceId = $this->option('device');
        $dates = $this->resolveDates();

        if ($dates === null) {
            $this->error('Kombinasi opsi tanggal tidak valid. Pakai --date=Y-m-d ATAU --from=Y-m-d --to=Y-m-d (bukan keduanya).');
            return self::FAILURE;
        }

        $query = AttendanceDevice::where('status', 'active')->where('sync_mode', 'scheduled');
        if ($deviceId) $query->where('id', $deviceId);

        $devices = $query->get();

        if ($devices->isEmpty()) {
            $this->warn('Tidak ada mesin aktif dengan mode sync=scheduled.');
            return self::SUCCESS;
        }

        $totalJobs = 0;
        foreach ($dates as $date) {
            foreach ($devices as $device) {
                SyncFingerspotAttendanceJob::dispatch($device->id, $date);
                $totalJobs++;
            }
        }

        $rangeLabel = count($dates) > 1 ? (count($dates) . ' tanggal (' . $dates[0] . ' s/d ' . end($dates) . ')') : $dates[0];
        $this->info("Dijadwalkan: {$devices->count()} mesin x {$rangeLabel} = {$totalJobs} job ke queue.");
        $this->comment('Data yang sudah pernah sync otomatis di-skip (aman diulang / backdate).');

        return self::SUCCESS;
    }

    /** @return array<string>|null daftar tanggal Y-m-d, atau null kalau kombinasi opsi tidak valid */
    protected function resolveDates(): ?array
    {
        $single = $this->option('date');
        $from = $this->option('from');
        $to = $this->option('to');

        if ($single && ($from || $to)) return null; // tidak boleh campur --date dengan --from/--to
        if ($from xor $to) return null; // --from dan --to harus diisi berdua

        if ($from && $to) {
            $start = Carbon::parse($from);
            $end = Carbon::parse($to);
            if ($end->lt($start)) return null;

            $dates = [];
            $cursor = $start->copy();
            while ($cursor->lte($end)) {
                $dates[] = $cursor->format('Y-m-d');
                $cursor->addDay();
            }
            return $dates;
        }

        return [$single ?? now()->format('Y-m-d')];
    }
}
