<?php

namespace App\Services\Employee;

use App\Models\AttendanceDevice;
use App\Models\Company;
use App\Models\DeviceEmployeeMapping;
use App\Models\Employee;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

/**
 * Logika inti import karyawan dari file export Fingerspot Cloud, dipakai bersama
 * oleh command CLI (`employees:import-fingerspot`) dan endpoint upload dari UI
 * (`AttendanceDeviceController::importEmployees`).
 *
 * Format kolom yang diharapkan: ID | NIK | Nama di perangkat absensi | Nama Depan |
 * Nama Belakang | Jenis Kelamin | Tanggal Bergabung | Kantor | Jabatan | Telp
 *
 * CATATAN: Kolom 'NIK' pada file export TIDAK unik. Kolom 'ID' (PIN mesin) dipakai
 * sebagai identifier unik untuk mencocokkan data, bukan NIK.
 */
class FingerspotEmployeeImportService
{
    public const EXPECTED_COLUMNS = ['ID', 'NIK', 'Nama di perangkat absensi', 'Nama Depan', 'Nama Belakang', 'Jenis Kelamin', 'Tanggal Bergabung', 'Kantor', 'Jabatan', 'Telp'];

    /**
     * @param  string  $filePath  Path absolut ke file .xlsx
     * @param  string|null  $companyId  Kalau diisi, SEMUA baris masuk ke company ini
     *         (dipakai saat import lewat UI device — company sudah pasti dari device-nya).
     *         Kalau NULL, company ditentukan otomatis per-baris dari kolom "Kantor"
     *         (dipakai saat import lewat CLI tanpa --company).
     * @param  string|null  $deviceId  Kalau diisi, PIN otomatis dipetakan ke device ini.
     * @param  callable|null  $onProgress  Callback opsional dipanggil tiap baris diproses,
     *         berguna untuk progress bar CLI. Signature: function(int $current, int $total).
     *
     * @return array{created:int, updated:int, mapped:int, skipped:int, total:int, companies_created:array}
     */
    public function importFromFile(string $filePath, ?string $companyId = null, ?string $deviceId = null, ?callable $onProgress = null): array
    {
        if (! file_exists($filePath)) {
            throw new \RuntimeException("File tidak ditemukan: {$filePath}");
        }

        $spreadsheet = IOFactory::load($filePath);
        $rows = $spreadsheet->getActiveSheet()->toArray(null, true, true, false);

        if (empty($rows)) {
            throw new \RuntimeException('File kosong atau tidak bisa dibaca.');
        }

        $header = array_map('trim', $rows[0]);
        foreach (self::EXPECTED_COLUMNS as $col) {
            if (! in_array($col, $header, true)) {
                throw new \RuntimeException("Kolom '{$col}' tidak ditemukan di file. Kolom yang terbaca: " . implode(', ', $header));
            }
        }

        $colIndex = array_flip($header);
        $dataRows = array_slice($rows, 1);
        $total = count($dataRows);

        $device = $deviceId ? AttendanceDevice::findOrFail($deviceId) : null;

        $created = 0; $updated = 0; $mapped = 0; $skipped = 0;
        $companyCache = [];
        $companiesCreated = [];

        foreach ($dataRows as $i => $row) {
            if ($onProgress) $onProgress($i + 1, $total);

            if (empty($row[$colIndex['ID']])) { $skipped++; continue; }

            $pin = (string) $row[$colIndex['ID']];
            $namaDepan = trim((string) $row[$colIndex['Nama Depan']]);
            $namaBelakang = trim((string) ($row[$colIndex['Nama Belakang']] ?? ''));
            $fullName = trim("{$namaDepan} {$namaBelakang}");
            $kantor = trim((string) $row[$colIndex['Kantor']]);
            $gender = trim((string) $row[$colIndex['Jenis Kelamin']]) ?: null;
            $jabatan = trim((string) $row[$colIndex['Jabatan']]) ?: null;
            $joinDate = $this->parseDate($row[$colIndex['Tanggal Bergabung']] ?? null);
            $telp = trim((string) ($row[$colIndex['Telp']] ?? '')) ?: null;

            // Kalau $companyId eksplisit diisi (import lewat device tertentu), pakai itu
            // untuk SEMUA baris. Kalau tidak, tentukan otomatis per-baris dari kolom Kantor.
            $rowCompanyId = $companyId ?: $this->resolveCompanyId($kantor, $companyCache, $companiesCreated);

            $employee = Employee::updateOrCreate(
                ['company_id' => $rowCompanyId, 'nik' => "PIN-{$pin}"],
                [
                    'name' => $fullName ?: "Karyawan PIN {$pin}",
                    'gender' => in_array($gender, ['L', 'P'], true) ? $gender : null,
                    'position' => $jabatan,
                    'department' => $jabatan,
                    'join_date' => $joinDate,
                    'phone' => $telp,
                    'status' => 'active',
                ]
            );

            $employee->wasRecentlyCreated ? $created++ : $updated++;

            if ($device) {
                DeviceEmployeeMapping::updateOrCreate(
                    ['device_id' => $device->id, 'device_pin' => $pin],
                    ['employee_id' => $employee->id, 'status' => 'active']
                );
                $mapped++;
            }
        }

        return [
            'created' => $created, 'updated' => $updated, 'mapped' => $mapped,
            'skipped' => $skipped, 'total' => $total, 'companies_created' => $companiesCreated,
        ];
    }

    protected function resolveCompanyId(string $kantorName, array &$cache, array &$companiesCreated): string
    {
        if (isset($cache[$kantorName])) return $cache[$kantorName];

        $company = Company::where('name', $kantorName)->first();

        if (! $company) {
            $code = 'PT-' . strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $kantorName), 0, 10));
            $company = Company::create(['code' => $code, 'name' => $kantorName, 'status' => 'active']);
            $companiesCreated[] = $company->name;
        }

        return $cache[$kantorName] = $company->id;
    }

    protected function parseDate($value): ?string
    {
        if (empty($value)) return null;
        try {
            if (is_numeric($value)) {
                return ExcelDate::excelToDateTimeObject($value)->format('Y-m-d');
            }
            return \Carbon\Carbon::parse($value)->format('Y-m-d');
        } catch (\Throwable) {
            return null;
        }
    }
}
