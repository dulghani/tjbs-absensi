<?php

namespace App\Services\Attendance;

use App\Models\AttendanceLog;
use App\Models\AttendanceSummary;
use App\Models\CompanyWorkSetting;
use App\Models\Employee;
use App\Models\EmployeeShift;
use App\Models\LeaveRequest;
use App\Models\OvertimeRequestDetail;
use Carbon\Carbon;

/**
 * Mengubah attendance_logs (raw punch in/out) jadi attendance_summaries
 * (hasil hitung: jam kerja, telat, lembur, dll) untuk SATU karyawan SATU hari.
 *
 * Urutan penentuan "jam kerja seharusnya" (expected shift):
 *   1. employee_shifts aktif pada tanggal tsb (kalau ada shift spesifik)
 *   2. fallback ke company_work_settings yang berlaku pada tanggal tsb
 *
 * Dipanggil oleh CalculateAttendanceSummaryJob (queued, dijadwalkan tiap malam).
 */
class AttendanceCalculationService
{
    public function calculateForEmployeeDate(string $employeeId, string $date): AttendanceSummary
    {
        $employee = Employee::findOrFail($employeeId);

        // Cuti disetujui? Tandai on_leave dan selesai, tidak perlu hitung jam kerja.
        $onLeave = LeaveRequest::where('employee_id', $employeeId)
            ->where('status', 'approved')
            ->where('start_date', '<=', $date)
            ->where('end_date', '>=', $date)
            ->exists();

        if ($onLeave) {
            return $this->upsert($employeeId, $employee->company_id, $date, [
                'attendance_status' => 'on_leave',
                'expected_work_minutes' => 0,
                'status' => 'auto_finalized',
            ]);
        }

        [$expectedStart, $expectedEnd, $expectedWorkMinutes, $overtimeMinThreshold] = $this->resolveExpectedShift($employee, $date);

        $logs = AttendanceLog::where('employee_id', $employeeId)
            ->whereBetween('logged_time', [
                Carbon::parse($date)->startOfDay(),
                Carbon::parse($date)->endOfDay()->addHours(12), // toleransi shift lintas tengah malam
            ])
            ->orderBy('logged_time')
            ->get();

        $checkIn = $logs->where('log_type', 'check_in')->first();
        // PENTING: checkout dicari yang terjadi SETELAH check-in ini, bukan sekadar checkout
        // TERAKHIR di window manapun. Untuk karyawan shift malam yang kerja berturut-turut,
        // window tanggal ini bisa ikut menangkap checkout SISA shift kemarin (closing-nya lewat
        // tengah malam, jadi tercatat pagi ini). Kalau checkout ASLI hari ini belum ada (mis.
        // dihitung sebelum karyawan pulang), tanpa filter ini sistem salah pasangkan check-in
        // hari ini dengan checkout sisa kemarin.
        $checkOut = $checkIn
            ? $logs->where('log_type', 'check_out')->filter(fn ($log) => $log->logged_time->gt($checkIn->logged_time))->first()
            : null;

        // Tidak ada hari kerja diharapkan (hari libur di kalender) dan tidak ada log -> rest_day.
        if (! $expectedStart && $logs->isEmpty()) {
            return $this->upsert($employeeId, $employee->company_id, $date, [
                'attendance_status' => 'rest_day',
                'expected_work_minutes' => 0,
                'status' => 'auto_finalized',
            ]);
        }

        // Kerja di hari libur terjadwal (mis. masuk hari Minggu) -> SEMUA jam kerja dihitung
        // sebagai "lembur merah" (shift_type=holiday), dipakai PayrollCalculationService untuk
        // bedakan tarif lembur hari libur vs lembur hari efektif biasa.
        if (! $expectedStart && $checkIn && $checkOut) {
            $holidayStart = Carbon::parse($checkIn->logged_time);
            $holidayEnd = Carbon::parse($checkOut->logged_time);
            if ($holidayEnd->lt($holidayStart)) $holidayEnd->addDay();
            $holidayMinutes = abs($holidayEnd->diffInMinutes($holidayStart));

            return $this->upsert($employeeId, $employee->company_id, $date, [
                'attendance_status' => 'present',
                'actual_start_time' => $holidayStart->format('H:i:s'),
                'actual_end_time' => $holidayEnd->format('H:i:s'),
                'expected_work_minutes' => 0,
                'actual_work_minutes' => $holidayMinutes,
                'productive_work_minutes' => $holidayMinutes,
                'overtime_minutes' => $holidayMinutes,
                'overtime_verified' => $holidayMinutes > 0 ? $this->hasApprovedOvertime($employeeId, $date) : null,
                'shift_type' => 'holiday',
                'status' => 'auto_finalized',
            ]);
        }

        // Tidak check-in sama sekali padahal ada jadwal kerja -> absen.
        if (! $checkIn) {
            return $this->upsert($employeeId, $employee->company_id, $date, [
                'attendance_status' => 'absent',
                'expected_start_time' => $expectedStart, 'expected_end_time' => $expectedEnd,
                'expected_work_minutes' => $expectedWorkMinutes,
                'status' => 'auto_finalized',
            ]);
        }

        $actualStart = Carbon::parse($checkIn->logged_time);
        $actualEnd = $checkOut ? Carbon::parse($checkOut->logged_time) : null;

        // Shift lintas tengah malam: Fingerspot mencatat 'Date Time' checkout dengan
        // tanggal yang SAMA dengan awal shift (business date), bukan tanggal kalender
        // sebenarnya. Kalau checkout secara waktu lebih awal dari checkin (mis. checkin
        // 16:01, checkout tercatat 00:08 di "tanggal" yang sama), itu tandanya checkout
        // sebenarnya terjadi di hari kalender BERIKUTNYA — geser +1 hari sebelum dihitung.
        if ($actualEnd && $actualEnd->lt($actualStart)) {
            $actualEnd->addDay();
        }

        $lateMinutes = 0;
        if ($expectedStart) {
            $expectedStartDt = Carbon::parse($date . ' ' . $expectedStart);
            // abs() penting: diffInMinutes() di versi Carbon ini mengembalikan nilai
            // BERTANDA (bisa negatif tergantung arah), bukan selalu absolut positif.
            $lateMinutes = $actualStart->gt($expectedStartDt) ? abs($actualStart->diffInMinutes($expectedStartDt)) : 0;
        }

        $earlyLeaveMinutes = 0;
        $actualWorkMinutes = 0;
        $overtimeMinutes = 0;
        $undertimeMinutes = 0;

        if ($actualEnd) {
            $actualWorkMinutes = abs($actualEnd->diffInMinutes($actualStart));

            if ($expectedEnd) {
                $expectedEndDt = Carbon::parse($date . ' ' . $expectedEnd);
                if ($expectedEndDt->lt(Carbon::parse($date . ' ' . $expectedStart))) $expectedEndDt->addDay(); // shift malam
                if ($actualEnd->lt($expectedEndDt)) {
                    $earlyLeaveMinutes = abs($expectedEndDt->diffInMinutes($actualEnd));
                }
            }

            if ($expectedWorkMinutes > 0) {
                $diff = $actualWorkMinutes - $expectedWorkMinutes;
                // Selisih lebih dari jam kerja default dianggap lembur HANYA kalau sudah
                // memenuhi ambang minimal lembur perusahaan (overtime_min_minutes, default 30
                // menit) — supaya selisih kecil wajar (mis. 5 menit lewat) tidak dihitung lembur.
                if ($diff >= $overtimeMinThreshold) $overtimeMinutes = $diff;
                elseif ($diff < 0) $undertimeMinutes = abs($diff);
            }
        }

        $status = 'present';
        if ($lateMinutes > 0) $status = 'late';
        if ($earlyLeaveMinutes > 0 && $status === 'present') $status = 'early_leave';

        // Verifikasi silang lembur: begitu overtime_minutes terisi (artinya sudah lolos ambang
        // minimal lembur perusahaan), cek apakah ada pengajuan lembur disetujui yang cocok.
        // Ada & cocok -> overtime_verified=true (hijau di UI). Tidak ada -> false (kuning,
        // warning supaya HRD/petugas lapangan cek manual — lembur tercatat tanpa pengajuan resmi).
        $overtimeVerified = null;
        if ($overtimeMinutes > 0) {
            $overtimeVerified = $this->hasApprovedOvertime($employeeId, $date);
        }

        return $this->upsert($employeeId, $employee->company_id, $date, [
            'attendance_status' => $status,
            'expected_start_time' => $expectedStart, 'expected_end_time' => $expectedEnd,
            'actual_start_time' => $actualStart->format('H:i:s'),
            'actual_end_time' => $actualEnd?->format('H:i:s'),
            'late_minutes' => $lateMinutes,
            'early_leave_minutes' => $earlyLeaveMinutes,
            'expected_work_minutes' => $expectedWorkMinutes,
            'actual_work_minutes' => $actualWorkMinutes,
            'productive_work_minutes' => $actualWorkMinutes, // TODO: kurangi break_minutes kalau ada log break_start/end
            'overtime_minutes' => $overtimeMinutes,
            'overtime_verified' => $overtimeVerified,
            'undertime_minutes' => $undertimeMinutes,
            'status' => 'auto_finalized',
        ]);
    }

    /** @return array{0: ?string, 1: ?string, 2: int} [expected_start, expected_end, expected_work_minutes] */
    protected function resolveExpectedShift(Employee $employee, string $date): array
    {
        $employeeShift = EmployeeShift::where('employee_id', $employee->id)
            ->where('status', 'active')
            ->where('start_date', '<=', $date)
            ->where(fn ($q) => $q->whereNull('end_date')->orWhere('end_date', '>=', $date))
            ->with('shift')
            ->first();

        if ($employeeShift?->shift) {
            $shift = $employeeShift->shift;
            return [$shift->start_time, $shift->end_time, $shift->total_work_minutes, 30]; // 30 = default ambang lembur kalau pakai shift spesifik (belum ada override per-shift)
        }

        // Fallback: pakai aturan kerja umum perusahaan (company_work_settings) yang berlaku
        // pada tanggal tsb (versioning: ambil yang effective_date <= $date, paling baru).
        $setting = CompanyWorkSetting::where('company_id', $employee->company_id)
            ->where('effective_date', '<=', $date)
            ->orderByDesc('effective_date')
            ->first();

        if (! $setting) return [null, null, 0, 30];

        // Cek apakah tanggal ini termasuk hari kerja menurut work_days ([1,1,1,1,1,0,0] Senin..Minggu).
        $dayOfWeek = Carbon::parse($date)->dayOfWeekIso; // 1=Senin .. 7=Minggu
        $workDays = $setting->work_days ?? [1, 1, 1, 1, 1, 1, 0];
        if (empty($workDays[$dayOfWeek - 1])) return [null, null, 0, 30]; // hari libur terjadwal

        // Override jam kerja khusus hari tertentu (mis. Sabtu cuma 5 jam), kalau ada.
        $override = ($setting->daily_hours_override ?? [])[(string) $dayOfWeek] ?? null;
        $startTime = $override['start_time'] ?? $setting->work_start_time;
        $endTime = $override['end_time'] ?? $setting->work_end_time;

        $start = Carbon::parse($startTime);
        $end = Carbon::parse($endTime);
        $minutes = abs($end->diffInMinutes($start)) - ($setting->break_duration_minutes ?? 0);

        return [$startTime, $endTime, max(0, $minutes), $setting->overtime_min_minutes ?? 30];
    }

    protected function hasApprovedOvertime(string $employeeId, string $date): bool
    {
        return OvertimeRequestDetail::whereHas('overtimeRequest', function ($q) use ($date) {
            $q->where('overtime_date', $date)->where('status', 'approved');
        })->where('employee_id', $employeeId)->where('status', 'approved')->exists();
    }

    protected function upsert(string $employeeId, string $companyId, string $date, array $attrs): AttendanceSummary
    {
        return AttendanceSummary::updateOrCreate(
            ['employee_id' => $employeeId, 'attendance_date' => $date],
            $attrs + ['company_id' => $companyId]
        );
    }
}
