<?php

namespace App\Services\Payroll;

use App\Models\AttendanceSummary;
use App\Models\CompanySalaryComponent;
use App\Models\Employee;
use App\Models\EmployeeSalaryComponent;
use App\Models\Payroll;
use App\Models\PayrollDetail;

/**
 * Hitung gross/net gaji SATU karyawan untuk SATU periode payroll berdasarkan model
 * "upah harian" (bukan gaji bulanan tetap) — umum dipakai untuk karyawan outsourcing/pabrik.
 *
 * Parameter dasar (component_type dari company_salary_components):
 *   daily_wage_rate        "Upah Per Hari"      — rate rupiah/hari, diset manual per perusahaan
 *                                                  (naik tiap tahun). Baris referensi, TIDAK
 *                                                  ikut dijumlah ke gross langsung.
 *   overtime_holiday       "Lembur Merah"       — rate rupiah/jam untuk lembur di hari libur,
 *                                                  diset manual per perusahaan.
 *
 * Parameter per-periode (dari Payroll::effective_work_days, diisi manual tiap proses payroll
 * karena jumlah hari kerja efektif beda tiap bulan):
 *   "Hari Kerja Efektif" — dipakai sebagai acuan hitung potongan absen.
 *
 * Earning otomatis (dihitung dari attendance_summaries, tidak perlu base_value):
 *   attendance_earning      "Kehadiran"      = upah_per_hari x hari_hadir_aktual
 *   overtime_regular        "Lembur Biasa"   = (upah_per_hari / 7) x jam_lembur_hari_efektif
 *   overtime_holiday        "Lembur Merah"   = rate_lembur_merah x jam_lembur_hari_libur
 *
 * Deduction otomatis:
 *   absence_deduction       "Potongan Absen"       = upah_per_hari x (hari_kerja_efektif - hari_hadir)
 *   early_leave_deduction   "Potongan Izin Pulang" = (upah_per_hari / 8 / 60) x total_menit_early_leave
 *
 * Tipe lama (fixed/percentage/per_hari/formula/manual) tetap didukung untuk komponen
 * tambahan seperti tunjangan/BPJS di luar formula upah harian di atas.
 */
class PayrollCalculationService
{
    public function calculateForPayroll(Payroll $payroll): void
    {
        $employees = Employee::where('company_id', $payroll->company_id)->where('status', 'active')->get();

        $totalGross = 0;
        $totalNet = 0;

        foreach ($employees as $employee) {
            $detail = $this->calculateForEmployee($employee, $payroll);
            $totalGross += $detail->gross_salary;
            $totalNet += $detail->net_salary;
        }

        $payroll->update([
            'employee_count' => $employees->count(),
            'total_gross' => $totalGross,
            'total_net' => $totalNet,
        ]);
    }

    public function calculateForEmployee(Employee $employee, Payroll $payroll): PayrollDetail
    {
        $summaries = AttendanceSummary::where('employee_id', $employee->id)
            ->whereMonth('attendance_date', $payroll->period_month)
            ->whereYear('attendance_date', $payroll->period_year)
            ->get();

        $hariHadir = $summaries->whereIn('attendance_status', ['present', 'late', 'early_leave'])->count();
        $overtimeRegularMinutes = $summaries->where('shift_type', '!=', 'holiday')->sum('overtime_minutes');
        $overtimeHolidayMinutes = $summaries->where('shift_type', 'holiday')->sum('overtime_minutes');
        $earlyLeaveMinutes = $summaries->sum('early_leave_minutes');

        // Hari kerja efektif dari input manual saat proses payroll. Kalau tidak diisi
        // (mis. payroll lama sebelum fitur ini ada), fallback ke hari_hadir supaya
        // potongan absen otomatis 0 (tidak salah hukum karyawan karena data tidak lengkap).
        $hariKerjaEfektif = $payroll->effective_work_days ?? $hariHadir;
        $hariAbsen = max(0, $hariKerjaEfektif - $hariHadir);

        $components = CompanySalaryComponent::where('company_id', $employee->company_id)->orderBy('sort_order')->get();
        $overrides = EmployeeSalaryComponent::where('employee_id', $employee->id)
            ->whereIn('salary_component_id', $components->pluck('id'))
            ->get()->keyBy('salary_component_id');

        $dailyWageComponent = $components->firstWhere('calculation_type', 'daily_wage_rate');
        $dailyWageOverride = $dailyWageComponent ? $overrides->get($dailyWageComponent->id) : null;
        $dailyWage = (float) ($dailyWageOverride->custom_value ?? $dailyWageComponent?->base_value ?? 0);

        $ctx = [
            'daily_wage' => $dailyWage,
            'hari_hadir' => $hariHadir,
            'hari_kerja_efektif' => $hariKerjaEfektif,
            'hari_absen' => $hariAbsen,
            'overtime_regular_minutes' => $overtimeRegularMinutes,
            'overtime_holiday_minutes' => $overtimeHolidayMinutes,
            'early_leave_minutes' => $earlyLeaveMinutes,
        ];

        $breakdown = [];
        $grossEarning = 0;
        $totalDeduction = 0;

        foreach ($components as $component) {
            $override = $overrides->get($component->id);

            // "Upah Per Hari" itu RATE referensi, bukan nilai yang langsung dijumlah ke gross
            // (nilainya sudah "dipakai" lewat komponen attendance_earning/overtime_regular/dst).
            // Tetap ditampilkan di breakdown supaya slip gaji transparan soal dasar hitungnya.
            if ($component->calculation_type === 'daily_wage_rate') {
                $breakdown[] = ['name' => $component->component_name, 'type' => 'reference', 'calc' => $component->calculation_type, 'value' => round($dailyWage, 2)];
                continue;
            }

            $value = $this->resolveComponentValue($component, $override, $ctx);

            $breakdown[] = ['name' => $component->component_name, 'type' => $component->component_type, 'calc' => $component->calculation_type, 'value' => round($value, 2)];

            if ($component->component_type === 'earning') $grossEarning += $value;
            else $totalDeduction += $value;
        }

        $netSalary = $grossEarning - $totalDeduction;

        return PayrollDetail::updateOrCreate(
            ['payroll_id' => $payroll->id, 'employee_id' => $employee->id],
            [
                'total_work_days' => $hariHadir,
                'total_work_hours' => round($summaries->sum('productive_work_minutes') / 60, 2),
                'total_overtime_hours' => round(($overtimeRegularMinutes + $overtimeHolidayMinutes) / 60, 2),
                'component_breakdown' => $breakdown,
                'gross_salary' => round($grossEarning, 2),
                'total_deduction' => round($totalDeduction, 2),
                'net_salary' => round($netSalary, 2),
            ]
        );
    }

    protected function resolveComponentValue(CompanySalaryComponent $component, ?EmployeeSalaryComponent $override, array $ctx): float
    {
        // Override manual per-karyawan selalu menang kalau diisi (mis. koreksi khusus 1 orang).
        if ($override?->custom_value !== null) return (float) $override->custom_value;

        $dailyWage = $ctx['daily_wage'];

        return match ($component->calculation_type) {
            // ── Tipe lama, tetap didukung untuk komponen tambahan (tunjangan, BPJS, dll) ──
            'fixed' => (float) ($component->base_value ?? 0),
            'percentage' => $dailyWage * $ctx['hari_kerja_efektif'] * ((float) ($component->base_value ?? 0) / 100),
            'per_hari' => (float) ($component->base_value ?? 0) * $ctx['hari_hadir'],
            'formula' => $this->evalSimpleFormula($component->formula, ['base_salary' => $dailyWage * $ctx['hari_kerja_efektif']]),

            // ── Formula upah harian spesifik ──
            'attendance_earning' => $dailyWage * $ctx['hari_hadir'],
            'overtime_regular' => ($dailyWage / 7) * ($ctx['overtime_regular_minutes'] / 60),
            'overtime_holiday' => (float) ($component->base_value ?? 0) * ($ctx['overtime_holiday_minutes'] / 60),
            'absence_deduction' => $dailyWage * $ctx['hari_absen'],
            'early_leave_deduction' => $dailyWage > 0 ? ($dailyWage / 8 / 60) * $ctx['early_leave_minutes'] : 0,

            default => 0, // 'manual' -> harus diisi lewat employee_salary_components override
        };
    }

    /** Evaluator formula SANGAT terbatas & aman (tanpa eval()) — hanya mendukung "base_salary * X" atau "base_salary + X". */
    protected function evalSimpleFormula(?string $formula, array $vars): float
    {
        if (! $formula) return 0;
        $formula = trim($formula);

        if (preg_match('/^base_salary\s*\*\s*([\d.]+)$/', $formula, $m)) return $vars['base_salary'] * (float) $m[1];
        if (preg_match('/^base_salary\s*\+\s*([\d.]+)$/', $formula, $m)) return $vars['base_salary'] + (float) $m[1];
        if (preg_match('/^base_salary\s*-\s*([\d.]+)$/', $formula, $m)) return $vars['base_salary'] - (float) $m[1];

        return 0;
    }
}
