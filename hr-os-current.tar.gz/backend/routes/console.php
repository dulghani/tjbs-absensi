<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ── Sinkronisasi mesin fingerprint (Modul 3 - Attendance Engine) ────────────────
Schedule::command('attendance:sync-devices')
    ->everyFifteenMinutes()
    ->withoutOverlapping(10)
    ->onOneServer()
    ->appendOutputTo(storage_path('logs/attendance-sync.log'));

// Sync "penutup" dini hari untuk menangkap punch shift malam yang baru
// selesai setelah tengah malam.
Schedule::command('attendance:sync-devices', ['--date' => now()->subDay()->format('Y-m-d')])
    ->dailyAt('01:00');

// ── Hitung ulang attendance_summaries (Modul 3) ──────────────────────────────
// Jaring pengaman: SyncFingerspotAttendanceJob sudah trigger kalkulasi otomatis
// begitu sync selesai, tapi task ini pastikan SEMUA karyawan aktif tetap
// tercatat (termasuk yang device-nya offline / tidak absen sama sekali -> absent),
// bukan cuma yang kebetulan ada log.
Schedule::command('attendance:calculate-summaries', ['--all-active' => true])
    ->dailyAt('02:00')
    ->withoutOverlapping(30);
