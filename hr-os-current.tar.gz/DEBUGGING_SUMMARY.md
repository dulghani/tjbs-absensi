# Rangkuman Debugging — Integrasi Fingerspot & Setup Laravel

Dokumen ini merangkum seluruh masalah yang ditemukan selama setup project OutsourceHR
(backend Laravel + integrasi mesin fingerprint Fingerspot) di environment Laragon, solusi
yang diterapkan, dan gambaran arsitektur sistem setelah semua perbaikan.

---

## 1. Daftar Masalah & Solusi (Kronologis)

| # | Masalah | Akar Penyebab | Solusi |
|---|---|---|---|
| 1 | Tampilan frontend polos tanpa styling | Tailwind CSS v4 gagal ter-compile di sebagian environment | Downgrade ke Tailwind v3.4 (lebih stabil, konfigurasi klasik) |
| 2 | `php: command not found` di Git Bash | Git Bash biasa tidak otomatis dapat PATH dari Laragon | Pakai **Terminal bawaan Laragon**, atau tambahkan PHP ke PATH manual |
| 3 | `composer install` gagal — security advisory | Composer versi baru block install kalau ada advisory Laravel yang terdeteksi | `composer config audit.block-insecure false` |
| 4 | Error `ilike` di pencarian karyawan | `ilike` adalah operator khusus PostgreSQL, tidak ada di MySQL (default Laragon) | Ganti ke `whereLike()` Laravel — portable ke MySQL/PostgreSQL/SQLite |
| 5 | `CSRF token mismatch` saat login | Middleware `EnsureFrontendRequestsAreStateful` (pola cookie-based SPA) terpasang, padahal frontend pakai Bearer token murni | Hapus middleware itu dari `bootstrap/app.php` — auth cukup lewat `auth:sanctum` per-route |
| 6 | Command `attendance:calculate-summaries` "not defined" | File baru belum di-copy ke project lokal, dan cache config lama masih dipakai | Copy file + `php artisan optimize:clear` |
| 7 | NIK di file Excel Fingerspot ternyata tidak unik | Kolom "NIK" isinya kode grup/batch (banyak karyawan share nilai sama) | Import pakai kolom **PIN mesin** (kolom "ID") sebagai identifier unik, bukan NIK |
| 8 | Sync Fingerspot: `Skip=100%, Masuk=0` | Nama field response API asli (`PIN`, `Date Time`, `Type`) beda dari asumsi awal (`pin`, `scan_date`, `in_out`) | Buat command diagnostik `fingerspot:debug-raw` untuk lihat response asli → sesuaikan parsing di `SyncFingerspotAttendanceJob` |
| 9 | Tanggal sync mundur 1 hari (10 Jul vs 11 Jul asli) | `config/app.php` timezone hardcode `UTC`, tidak baca `.env` | Ubah jadi `env('APP_TIMEZONE', 'Asia/Jakarta')` |
| 10 | Semua record `Unmapped` setelah field mapping benar | Mapping PIN↔karyawan belum pernah dibuat (device dibuat manual via tinker/UI, tapi command import dengan `--device` belum dijalankan) | Jalankan ulang `employees:import-fingerspot ... --device={id}` |
| 11 | Data absensi "kotor" (banyak baris kosong) | Sisa hasil `calculate-summaries` dari sebelum semua fix di atas selesai (status `absent` palsu) | `AttendanceSummary::truncate()`, hitung ulang dari raw log yang sudah bersih |
| 12 | Jam masuk mundur 7 jam (07:55 tampil jadi 00:55) | **Double timezone conversion**: waktu asli WIB dikonversi ke UTC saat simpan, lalu dibaca ulang seolah sudah WIB (karena app timezone sudah Asia/Jakarta) | Hapus konversi `->setTimezone('UTC')` — simpan & baca konsisten pakai Asia/Jakarta saja |
| 13 | Mayoritas karyawan berstatus "Hari Libur" | `company_work_settings` belum pernah diisi untuk perusahaan ini | Buat record `CompanyWorkSetting` via tinker dengan `effective_date` di masa lalu (bukan default bulan depan) |
| 14 | Error enum `overtime_calc_method` | Saya kasih contoh nilai `'per_jam'` (Indonesia), padahal kolom cuma terima `'per_hour'`/`'per_15min'`/`'flat'` (Inggris) | Pakai `'per_hour'` |
| 15 | `calculate-summaries` jalan tapi hasil masih kosong | Kemungkinan race condition — command dispatch ke **queue**, tapi `queue:work` sempat tidak jalan/tidak sempat proses semua job | Cek `jobs`/`failed_jobs` table, pastikan `queue:work` aktif sebelum cek hasil |

---

## 2. Prinsip Desain yang Ditetapkan Selama Debugging

Beberapa keputusan arsitektur yang "mengeras" jadi aturan tetap sistem ini, hasil dari
proses debug di atas:

### Timezone: Satu Zona Waktu Konsisten (Asia/Jakarta)
Sistem ini **sengaja tidak** pakai pola "simpan UTC, tampilkan lokal" yang umum di aplikasi
multi-region. Karena target pengguna cuma Indonesia (WIB), semua lapisan — `config/app.php`,
`now()`, parsing waktu Fingerspot, tampilan di frontend — konsisten pakai **Asia/Jakarta**
dari ujung ke ujung. Ini menyederhanakan banyak hal, tapi artinya **kalau nanti sistem ini
dipakai lintas zona waktu (WITA/WIT atau luar negeri), perlu redesign ulang bagian ini.**

### PIN Mesin, Bukan NIK, Sebagai Identifier Karyawan dari Fingerspot
Data NIK di file export Fingerspot tidak reliable (tidak unik). Semua proses matching
(import karyawan, sync absensi) berpatokan ke **PIN mesin** (`device_employee_mappings`),
bukan NIK. NIK tetap disimpan di database untuk referensi, tapi tidak dipakai untuk logic.

### Semua Proses Berat Lewat Queue (Async)
Sync Fingerspot dan kalkulasi absensi/payroll **tidak** berjalan langsung saat request HTTP
masuk — semua di-dispatch ke queue (`jobs` table) dan diproses terpisah oleh `queue:work`.
Konsekuensinya: **`queue:work` harus selalu aktif** selama development maupun production,
kalau tidak, job cuma menumpuk tanpa diproses.

---

## 3. Arsitektur Sistem Saat Ini

### Alur Data Lengkap: Fingerspot → Dashboard

```
┌─────────────────────┐
│  Mesin Fingerprint   │  (Fingerspot Cloud, per lokasi/kantor)
│  cloud_id + api_key  │
└──────────┬───────────┘
           │ (1) FingerspotService::fetchAttendanceLog()
           │     GET dengan auth MD5(cloud_id+date+timestamp+api_key)
           ▼
┌──────────────────────────────┐
│ SyncFingerspotAttendanceJob   │  (queued, per device per tanggal)
│  - baca field: PIN, Date Time,│
│    Type / Type ID             │
│  - cocokkan PIN → employee_id │
│    lewat device_employee_     │
│    mappings                   │
│  - simpan ke attendance_logs  │
│    (skip kalau sudah ada)     │
└──────────┬────────────────────┘
           │ (2) trigger otomatis per karyawan yang datanya baru masuk
           ▼
┌──────────────────────────────┐
│ CalculateAttendanceSummaryJob │  (queued, per karyawan per tanggal)
│  → AttendanceCalculationService│
│  - ambil expected shift dari  │
│    employee_shifts ATAU       │
│    company_work_settings      │
│  - hitung telat/lembur/jam    │
│    kerja aktual               │
│  - simpan ke                  │
│    attendance_summaries       │
└──────────┬────────────────────┘
           │ (3) dipakai saat proses payroll
           ▼
┌──────────────────────────────┐
│  CalculatePayrollJob          │  (queued, per proses payroll)
│  → PayrollCalculationService  │
│  - agregat attendance_summaries│
│    1 bulan                    │
│  - hitung gross/net per       │
│    komponen gaji + lembur     │
│  - simpan ke payroll_details  │
└────────────────────────────────┘
```

### Jadwal Otomatis (Scheduler — butuh `php artisan schedule:work` aktif)

| Waktu | Command | Fungsi |
|---|---|---|
| Tiap 15 menit | `attendance:sync-devices` | Sync semua device aktif untuk hari ini |
| 01:00 dini hari | `attendance:sync-devices --date=kemarin` | Tangkap shift malam yang baru selesai lewat tengah malam |
| 02:00 dini hari | `attendance:calculate-summaries --all-active` | Jaring pengaman — pastikan SEMUA karyawan aktif ke-cover (termasuk yang device-nya offline → tertandai absent) |

### File-File Kunci (Backend)

```
app/
├── Services/
│   ├── Attendance/
│   │   ├── FingerspotService.php          # Client API Fingerspot (auth, fetch log)
│   │   └── AttendanceCalculationService.php # Raw log → summary (telat/lembur/jam kerja)
│   └── Payroll/
│       └── PayrollCalculationService.php   # Summary → gaji aktual (gross/net)
├── Jobs/
│   ├── SyncFingerspotAttendanceJob.php     # Orchestrator sync 1 device 1 tanggal
│   ├── CalculateAttendanceSummaryJob.php   # Wrapper queue utk 1 karyawan 1 tanggal
│   └── CalculatePayrollJob.php             # Wrapper queue utk 1 proses payroll
├── Console/Commands/
│   ├── SyncAttendanceDevices.php           # Trigger sync semua device (dipanggil scheduler)
│   ├── CalculateAttendanceSummaries.php    # Trigger kalkulasi batch
│   ├── ImportFingerspotEmployees.php       # Import karyawan dari xlsx export
│   └── DebugFingerspotRaw.php              # Diagnostic — dump response API mentah
└── Http/Controllers/Api/
    ├── AttendanceDeviceController.php       # CRUD device, test koneksi, sync manual (dari UI)
    ├── AttendanceController.php             # Check-in/out manual, lihat summary
    └── PayrollController.php                # Proses payroll, aturan kerja, komponen gaji
```

### Tabel Database Terkait (MySQL)

```
attendance_devices          # Kredensial Fingerspot per device (api_key terenkripsi)
device_employee_mappings    # PIN mesin ↔ employee_id (bukan NIK!)
attendance_sync_logs        # Riwayat tiap percobaan sync (fetched/inserted/skipped/unmapped)
attendance_logs             # Raw punch in/out (sumber kebenaran mentah)
attendance_summaries        # Hasil kalkulasi per karyawan per hari
company_work_settings       # Aturan jam kerja per perusahaan (versioned by effective_date)
company_overtime_rates      # Tier multiplier lembur
payrolls / payroll_details  # Hasil akhir perhitungan gaji
```

---

## 4. Status Saat Ini

✅ **Sudah berfungsi:**
- Login (Bearer token, tanpa CSRF issue)
- Import karyawan dari Excel Fingerspot (82 karyawan, PIN sebagai key)
- Sync absensi dari Fingerspot API (field mapping sudah benar: PIN, Date Time, Type)
- Timezone konsisten Asia/Jakarta di seluruh sistem
- Kalkulasi status Hadir/Absen berdasarkan `company_work_settings`

🔄 **Sedang diverifikasi (real-time saat dokumen ini dibuat):**
- Apakah `queue:work` sudah memproses semua 82 job kalkulasi summary tanggal 11 Juli 2026

⚠️ **Belum dikerjakan / masih manual:**
- UI untuk isi `company_work_settings` pertama kali (saat ini masih lewat tinker manual, form UI ada tapi behavior default-nya untuk update periode berikutnya, bukan setup awal)
- CRUD tier lembur (`company_overtime_rates`) belum ada form-nya di UI (endpoint API sudah ada)
- Workflow engine generik (approval multi-step) — saat ini overtime approve/reject masih langsung, belum lewat `workflow_instances`
- Notification sending (email/SMS aktual) — tabel sudah ada, belum ada job pengirim

---

## 5. Pelajaran Penting untuk Development Selanjutnya

1. **Selalu restart `queue:work` setelah edit file Job/Service** — PHP proses lama tetap
   pakai kode lama sampai di-restart, ini penyebab paling sering "kok belum berubah".
2. **`php artisan optimize:clear` setelah edit config atau tambah command baru** — Laravel
   cache config & daftar command, perubahan tidak langsung kebaca.
3. **Command debug (`fingerspot:debug-raw`) jauh lebih cepat daripada tebak-tebak field
   API** — kalau nanti integrasi API pihak ketiga lain bermasalah, bikin command serupa dulu.
4. **`--all-active` di `calculate-summaries` vs mode default** — default cuma proses
   karyawan yang punya log hari itu (ringan), `--all-active` proses semua (perlu buat
   memastikan yang tidak absen pun tercatat "absent", bukan hilang dari laporan).
